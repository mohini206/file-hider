import javax.swing.*;
import javax.swing.border.EtchedBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.nio.file.*;
import java.nio.file.attribute.DosFileAttributes;

public class FileHiderMain extends JFrame {
    private JTextField filePathField;
    private JTextArea outputArea;
    private JButton hideButton, unhideButton, browseButton, checkStatusButton;
    
    public FileHiderMain() {
        initializeGUI();
    }
    
    private void initializeGUI() {
        setTitle("🔒 File Hider - Visual Studio Edition");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
        
        // Create components
        createComponents();
        layoutComponents();
        addEventListeners();
        
        setSize(800, 600);
        setLocationRelativeTo(null);
        
        // Set colors for better appearance
        getContentPane().setBackground(new Color(240, 240, 240));
    }
    
    private void createComponents() {
        filePathField = new JTextField(50);
        filePathField.setFont(new Font("Consolas", Font.PLAIN, 14));
        
        outputArea = new JTextArea(20, 60);
        outputArea.setEditable(false);
        outputArea.setFont(new Font("Consolas", Font.PLAIN, 12));
        outputArea.setBackground(new Color(248, 248, 248));
        outputArea.setText("🔒 File Hider Ready - Visual Studio Edition\n" +
                          "Select a file to hide or unhide...\n\n");
        
        hideButton = new JButton("🙈 Hide File");
        hideButton.setBackground(new Color(220, 53, 69));
        hideButton.setForeground(Color.WHITE);
        hideButton.setPreferredSize(new Dimension(140, 40));
        hideButton.setFont(new Font("Arial", Font.BOLD, 14));
        
        unhideButton = new JButton("👁️ Unhide File");
        unhideButton.setBackground(new Color(40, 167, 69));
        unhideButton.setForeground(Color.WHITE);
        unhideButton.setPreferredSize(new Dimension(140, 40));
        unhideButton.setFont(new Font("Arial", Font.BOLD, 14));
        
        browseButton = new JButton("📁 Browse Files");
        browseButton.setBackground(new Color(0, 123, 255));
        browseButton.setForeground(Color.WHITE);
        browseButton.setPreferredSize(new Dimension(140, 40));
        browseButton.setFont(new Font("Arial", Font.BOLD, 14));
        
        checkStatusButton = new JButton("🔍 Check Status");
        checkStatusButton.setBackground(new Color(108, 117, 125));
        checkStatusButton.setForeground(Color.WHITE);
        checkStatusButton.setPreferredSize(new Dimension(140, 40));
        checkStatusButton.setFont(new Font("Arial", Font.BOLD, 14));
    }
    
    private void layoutComponents() {
        // Top panel for file selection
        JPanel topPanel = new JPanel(new BorderLayout(10, 10));
        topPanel.setBackground(new Color(240, 240, 240));
        topPanel.setBorder(BorderFactory.createTitledBorder("📁 File Selection"));
        
        JLabel fileLabel = new JLabel("File Path:");
        fileLabel.setFont(new Font("Arial", Font.BOLD, 14));
        
        JPanel filePanel = new JPanel(new BorderLayout(5, 5));
        filePanel.setBackground(new Color(240, 240, 240));
        filePanel.add(fileLabel, BorderLayout.WEST);
        filePanel.add(filePathField, BorderLayout.CENTER);
        filePanel.add(browseButton, BorderLayout.EAST);
        
        topPanel.add(filePanel, BorderLayout.CENTER);
        
        // Middle panel for buttons
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 15));
        buttonPanel.setBackground(new Color(240, 240, 240));
        buttonPanel.setBorder(BorderFactory.createTitledBorder("🔧 File Operations"));
        
        buttonPanel.add(hideButton);
        buttonPanel.add(unhideButton);
        buttonPanel.add(checkStatusButton);
        
        // Bottom panel for output
        JScrollPane scrollPane = new JScrollPane(outputArea);
        scrollPane.setBorder(BorderFactory.createTitledBorder("📋 Output Console"));
        scrollPane.setPreferredSize(new Dimension(780, 300));
        
        add(topPanel, BorderLayout.NORTH);
        add(buttonPanel, BorderLayout.CENTER);
        add(scrollPane, BorderLayout.SOUTH);
    }
    
    private void addEventListeners() {
        browseButton.addActionListener(e -> browseForFile());
        hideButton.addActionListener(e -> hideFile());
        unhideButton.addActionListener(e -> unhideFile());
        checkStatusButton.addActionListener(e -> checkFileStatus());
    }
    
    private void browseForFile() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
        fileChooser.setCurrentDirectory(new File(System.getProperty("user.home")));
        
        int result = fileChooser.showOpenDialog(this);
        if (result == JFileChooser.APPROVE_OPTION) {
            File selectedFile = fileChooser.getSelectedFile();
            filePathField.setText(selectedFile.getAbsolutePath());
            appendOutput("📁 Selected file: " + selectedFile.getName() + "\n");
            appendOutput("📍 Full path: " + selectedFile.getAbsolutePath() + "\n\n");
        }
    }
    
    private void hideFile() {
        String filePath = filePathField.getText().trim();
        if (filePath.isEmpty()) {
            appendOutput("❌ ERROR: Please select a file first!\n\n");
            JOptionPane.showMessageDialog(this, "Please select a file first!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        try {
            Path path = Paths.get(filePath);
            
            if (!Files.exists(path)) {
                appendOutput("❌ ERROR: File does not exist: " + filePath + "\n\n");
                JOptionPane.showMessageDialog(this, "File does not exist!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            appendOutput("🔄 PROCESSING: Hiding file...\n");
            appendOutput("📁 Target: " + path.getFileName() + "\n");
            
            if (isWindows()) {
                // Windows: Set hidden attribute
                Files.setAttribute(path, "dos:hidden", true);
                appendOutput("🔧 Method: Windows DOS hidden attribute\n");
                appendOutput("✅ SUCCESS: File hidden successfully!\n");
            } else {
                // Unix/Linux: Rename with dot prefix
                Path parent = path.getParent();
                String fileName = path.getFileName().toString();
                
                if (!fileName.startsWith(".")) {
                    Path hiddenPath = parent.resolve("." + fileName);
                    Files.move(path, hiddenPath);
                    filePathField.setText(hiddenPath.toString());
                    appendOutput("🔧 Method: Unix dot-file renaming\n");
                    appendOutput("📝 New name: " + hiddenPath.getFileName() + "\n");
                    appendOutput("✅ SUCCESS: File hidden successfully!\n");
                } else {
                    appendOutput("⚠️ WARNING: File is already hidden!\n");
                    JOptionPane.showMessageDialog(this, "File is already hidden!", "Warning", JOptionPane.WARNING_MESSAGE);
                    return;
                }
            }
            
            appendOutput("🔒 Status: File is now INVISIBLE to normal file browsers\n");
            appendOutput("📍 Location: " + filePath + "\n");
            appendOutput("=" + "=".repeat(50) + "\n\n");
            
            JOptionPane.showMessageDialog(this, "File hidden successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            
        } catch (IOException e) {
            appendOutput("❌ FATAL ERROR: " + e.getMessage() + "\n\n");
            JOptionPane.showMessageDialog(this, "Error hiding file: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void unhideFile() {
        String filePath = filePathField.getText().trim();
        if (filePath.isEmpty()) {
            appendOutput("❌ ERROR: Please select a file first!\n\n");
            JOptionPane.showMessageDialog(this, "Please select a file first!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        try {
            Path path = Paths.get(filePath);
            
            if (!Files.exists(path)) {
                appendOutput("❌ ERROR: File does not exist: " + filePath + "\n\n");
                JOptionPane.showMessageDialog(this, "File does not exist!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            appendOutput("🔄 PROCESSING: Unhiding file...\n");
            appendOutput("📁 Target: " + path.getFileName() + "\n");
            
            if (isWindows()) {
                // Windows: Remove hidden attribute
                Files.setAttribute(path, "dos:hidden", false);
                appendOutput("🔧 Method: Windows DOS attribute removal\n");
                appendOutput("✅ SUCCESS: File unhidden successfully!\n");
            } else {
                // Unix/Linux: Remove dot prefix
                Path parent = path.getParent();
                String fileName = path.getFileName().toString();
                
                if (fileName.startsWith(".")) {
                    String unhiddenName = fileName.substring(1);
                    Path unhiddenPath = parent.resolve(unhiddenName);
                    Files.move(path, unhiddenPath);
                    filePathField.setText(unhiddenPath.toString());
                    appendOutput("🔧 Method: Unix dot-file renaming\n");
                    appendOutput("📝 New name: " + unhiddenPath.getFileName() + "\n");
                    appendOutput("✅ SUCCESS: File unhidden successfully!\n");
                } else {
                    appendOutput("⚠️ WARNING: File is not hidden!\n");
                    JOptionPane.showMessageDialog(this, "File is not hidden!", "Warning", JOptionPane.WARNING_MESSAGE);
                    return;
                }
            }
            
            appendOutput("👁️ Status: File is now VISIBLE to all file browsers\n");
            appendOutput("📍 Location: " + filePathField.getText() + "\n");
            appendOutput("=" + "=".repeat(50) + "\n\n");
            
            JOptionPane.showMessageDialog(this, "File unhidden successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            
        } catch (IOException e) {
            appendOutput("❌ FATAL ERROR: " + e.getMessage() + "\n\n");
            JOptionPane.showMessageDialog(this, "Error unhiding file: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void checkFileStatus() {
        String filePath = filePathField.getText().trim();
        if (filePath.isEmpty()) {
            appendOutput("❌ ERROR: Please select a file first!\n\n");
            JOptionPane.showMessageDialog(this, "Please select a file first!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        try {
            Path path = Paths.get(filePath);
            
            if (!Files.exists(path)) {
                appendOutput("❌ ERROR: File does not exist: " + filePath + "\n\n");
                JOptionPane.showMessageDialog(this, "File does not exist!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            boolean hidden = isHidden(path);
            String fileSize = formatFileSize(Files.size(path));
            
            appendOutput("=" + "=".repeat(30) + " FILE STATUS REPORT " + "=".repeat(30) + "\n");
            appendOutput("📁 File Name: " + path.getFileName() + "\n");
            appendOutput("📍 Full Path: " + filePath + "\n");
            appendOutput("👁️ Visibility: " + (hidden ? "🔒 HIDDEN" : "👀 VISIBLE") + "\n");
            appendOutput("📏 File Size: " + fileSize + "\n");
            appendOutput("📅 Last Modified: " + Files.getLastModifiedTime(path) + "\n");
            appendOutput("💻 Operating System: " + (isWindows() ? "Windows" : "Unix/Linux") + "\n");
            
            if (isWindows()) {
                try {
                    DosFileAttributes attrs = Files.readAttributes(path, DosFileAttributes.class);
                    appendOutput("🔧 DOS Attributes: ");
                    if (attrs.isReadOnly()) appendOutput("ReadOnly ");
                    if (attrs.isHidden()) appendOutput("Hidden ");
                    if (attrs.isSystem()) appendOutput("System ");
                    if (attrs.isArchive()) appendOutput("Archive ");
                    appendOutput("\n");
                } catch (IOException e) {
                    appendOutput("⚠️ Could not read DOS file attributes\n");
                }
            }
            
            appendOutput("🔍 Detection Method: " + (isWindows() ? "DOS Hidden Attribute" : "Dot-file Convention") + "\n");
            appendOutput("=" + "=".repeat(80) + "\n\n");
            
            // Show popup with status
            String statusMessage = String.format(
                "File: %s\nStatus: %s\nSize: %s", 
                path.getFileName(), 
                (hidden ? "🔒 HIDDEN" : "👀 VISIBLE"), 
                fileSize
            );
            JOptionPane.showMessageDialog(this, statusMessage, "File Status", JOptionPane.INFORMATION_MESSAGE);
            
        } catch (IOException e) {
            appendOutput("❌ FATAL ERROR: " + e.getMessage() + "\n\n");
            JOptionPane.showMessageDialog(this, "Error checking file: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private boolean isHidden(Path path) {
        try {
            if (isWindows()) {
                DosFileAttributes attrs = Files.readAttributes(path, DosFileAttributes.class);
                return attrs.isHidden();
            } else {
                return path.getFileName().toString().startsWith(".");
            }
        } catch (IOException e) {
            return false;
        }
    }
    
    private boolean isWindows() {
        return System.getProperty("os.name").toLowerCase().contains("windows");
    }
    
    private String formatFileSize(long bytes) {
        if (bytes < 1024) return bytes + " bytes";
        if (bytes < 1024 * 1024) return String.format("%.1f KB", bytes / 1024.0);
        if (bytes < 1024 * 1024 * 1024) return String.format("%.1f MB", bytes / (1024.0 * 1024));
        return String.format("%.1f GB", bytes / (1024.0 * 1024 * 1024));
    }
    
    private void appendOutput(String text) {
        SwingUtilities.invokeLater(() -> {
            outputArea.append(getCurrentTimestamp() + " " + text);
            outputArea.setCaretPosition(outputArea.getDocument().getLength());
        });
    }
    
    private String getCurrentTimestamp() {
        return "[" + java.time.LocalTime.now().format(
            java.time.format.DateTimeFormatter.ofPattern("HH:mm:ss")) + "]";
    }
    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                // Try to set system look and feel - FIXED VERSION
                for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                    if ("Windows".equals(info.getName())) {
                        UIManager.setLookAndFeel(info.getClassName());
                        break;
                    }
                }
            } catch (Exception e) {
                // Use default look and feel if Windows L&F not available
                System.out.println("Using default look and feel");
            }
            
            // Show splash screen
            JOptionPane.showMessageDialog(null, 
                "🔒 File Hider - Visual Studio Edition\n\n" +
                "Features:\n" +
                "• Hide/Unhide files on Windows & Linux\n" +
                "• Real-time status checking\n" +
                "• Professional GUI interface\n" +
                "• Detailed logging console\n\n" +
                "Ready to secure your files!", 
                "Welcome to File Hider", 
                JOptionPane.INFORMATION_MESSAGE);
            
            new FileHiderMain().setVisible(true);
        });
    }
}
