import java.io.IOException;
import java.nio.file.*;
import java.nio.file.attribute.DosFileAttributes;
import java.util.ArrayList;
import java.util.List;

public class SimpleFileHider {
    
    public boolean hideFile(String filePath) {
        try {
            Path path = Paths.get(filePath);
            
            if (!Files.exists(path)) {
                System.err.println("❌ File does not exist: " + filePath);
                return false;
            }
            
            if (isWindows()) {
                // On Windows, set the hidden attribute
                Files.setAttribute(path, "dos:hidden", true);
                System.out.println("✅ File hidden using DOS attribute: " + filePath);
            } else {
                // On Unix-like systems, rename file to start with dot
                Path parent = path.getParent();
                String fileName = path.getFileName().toString();
                
                if (!fileName.startsWith(".")) {
                    Path hiddenPath = parent.resolve("." + fileName);
                    Files.move(path, hiddenPath);
                    System.out.println("✅ File hidden by renaming: " + filePath + " -> " + hiddenPath);
                } else {
                    System.out.println("⚠️ File is already hidden: " + filePath);
                }
            }
            
            return true;
            
        } catch (IOException e) {
            System.err.println("❌ Error hiding file: " + filePath + " - " + e.getMessage());
            return false;
        }
    }
    
    public boolean unhideFile(String filePath) {
        try {
            Path path = Paths.get(filePath);
            
            if (!Files.exists(path)) {
                System.err.println("❌ File does not exist: " + filePath);
                return false;
            }
            
            if (isWindows()) {
                // On Windows, remove the hidden attribute
                Files.setAttribute(path, "dos:hidden", false);
                System.out.println("✅ File unhidden using DOS attribute: " + filePath);
            } else {
                // On Unix-like systems, remove the leading dot
                Path parent = path.getParent();
                String fileName = path.getFileName().toString();
                
                if (fileName.startsWith(".")) {
                    String unhiddenName = fileName.substring(1);
                    Path unhiddenPath = parent.resolve(unhiddenName);
                    Files.move(path, unhiddenPath);
                    System.out.println("✅ File unhidden by renaming: " + filePath + " -> " + unhiddenPath);
                } else {
                    System.out.println("⚠️ File is not hidden: " + filePath);
                }
            }
            
            return true;
            
        } catch (IOException e) {
            System.err.println("❌ Error unhiding file: " + filePath + " - " + e.getMessage());
            return false;
        }
    }
    
    public boolean isFileHidden(String filePath) {
        try {
            Path path = Paths.get(filePath);
            
            if (!Files.exists(path)) {
                return false;
            }
            
            if (isWindows()) {
                DosFileAttributes attrs = Files.readAttributes(path, DosFileAttributes.class);
                return attrs.isHidden();
            } else {
                return path.getFileName().toString().startsWith(".");
            }
            
        } catch (IOException e) {
            System.err.println("❌ Error checking if file is hidden: " + filePath + " - " + e.getMessage());
            return false;
        }
    }
    
    public List<String> findHiddenFiles(String directoryPath) {
        List<String> hiddenFiles = new ArrayList<>();
        
        try {
            Path dir = Paths.get(directoryPath);
            
            if (!Files.exists(dir) || !Files.isDirectory(dir)) {
                System.err.println("❌ Directory does not exist: " + directoryPath);
                return hiddenFiles;
            }
            
            Files.walk(dir, 1) // Only check immediate children
                .filter(Files::isRegularFile)
                .forEach(path -> {
                    if (isFileHidden(path.toString())) {
                        hiddenFiles.add(path.toString());
                    }
                });
                
        } catch (IOException e) {
            System.err.println("❌ Error scanning directory: " + directoryPath + " - " + e.getMessage());
        }
        
        return hiddenFiles;
    }
    
    private boolean isWindows() {
        return System.getProperty("os.name").toLowerCase().contains("windows");
    }
    
    // Test method
    public static void main(String[] args) {
        SimpleFileHider hider = new SimpleFileHider();
        
        if (args.length < 2) {
            System.out.println("🔒 Simple File Hider - Command Line Interface");
            System.out.println("Usage: java SimpleFileHider <hide|unhide|check|scan> <file_path>");
            System.out.println();
            System.out.println("Commands:");
            System.out.println("  hide   - Hide the specified file");
            System.out.println("  unhide - Unhide the specified file");
            System.out.println("  check  - Check if file is hidden");
            System.out.println("  scan   - Scan directory for hidden files");
            System.out.println();
            System.out.println("Examples:");
            System.out.println("  java SimpleFileHider hide \"C:\\test.txt\"");
            System.out.println("  java SimpleFileHider unhide \"C:\\test.txt\"");
            System.out.println("  java SimpleFileHider check \"C:\\test.txt\"");
            System.out.println("  java SimpleFileHider scan \"C:\\\"");
            return;
        }
        
        String operation = args[0].toLowerCase();
        String filePath = args[1];
        
        System.out.println("🔒 Simple File Hider");
        System.out.println("Operation: " + operation.toUpperCase());
        System.out.println("Target: " + filePath);
        System.out.println("System: " + (hider.isWindows() ? "Windows" : "Unix/Linux"));
        System.out.println("----------------------------------------");
        
        switch (operation) {
            case "hide":
                boolean hidden = hider.hideFile(filePath);
                System.out.println("Result: Hide operation " + (hidden ? "✅ SUCCESSFUL" : "❌ FAILED"));
                break;
                
            case "unhide":
                boolean unhidden = hider.unhideFile(filePath);
                System.out.println("Result: Unhide operation " + (unhidden ? "✅ SUCCESSFUL" : "❌ FAILED"));
                break;
                
            case "check":
                boolean isHidden = hider.isFileHidden(filePath);
                System.out.println("Result: File is " + (isHidden ? "🔒 HIDDEN" : "👀 VISIBLE"));
                break;
                
            case "scan":
                List<String> hiddenFiles = hider.findHiddenFiles(filePath);
                System.out.println("Result: Found " + hiddenFiles.size() + " hidden files:");
                if (hiddenFiles.isEmpty()) {
                    System.out.println("  (No hidden files found)");
                } else {
                    hiddenFiles.forEach(file -> System.out.println("  🔒 " + file));
                }
                break;
                
            default:
                System.out.println("❌ Unknown operation: " + operation);
                System.out.println("Valid operations: hide, unhide, check, scan");
                break;
        }
    }
}
