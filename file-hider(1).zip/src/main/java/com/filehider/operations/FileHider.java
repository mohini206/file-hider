package com.filehider.operations;

import com.filehider.database.DatabaseConnection;
import com.filehider.utils.Logger;

import java.io.IOException;
import java.nio.file.*;
import java.nio.file.attribute.DosFileAttributes;
import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class FileHider {
    private static final Logger logger = Logger.getInstance();
    
    public boolean hideFile(String filePath) {
        try {
            Path path = Paths.get(filePath);
            
            if (!Files.exists(path)) {
                logger.error("File does not exist: " + filePath);
                return false;
            }
            
            boolean success = false;
            
            if (isWindows()) {
                // On Windows, set the hidden attribute
                Files.setAttribute(path, "dos:hidden", true);
                success = true;
                logger.info("File hidden using DOS attribute: " + filePath);
            } else {
                // On Unix-like systems, rename file to start with dot
                Path parent = path.getParent();
                String fileName = path.getFileName().toString();
                
                if (!fileName.startsWith(".")) {
                    Path hiddenPath = parent.resolve("." + fileName);
                    Files.move(path, hiddenPath);
                    success = true;
                    logger.info("File hidden by renaming: " + filePath + " -> " + hiddenPath);
                } else {
                    logger.warn("File is already hidden: " + filePath);
                    success = true;
                }
            }
            
            if (success) {
                // Record hidden file in database
                recordHiddenFile(filePath);
            }
            
            return success;
            
        } catch (IOException e) {
            logger.error("Error hiding file: " + filePath + " - " + e.getMessage());
            return false;
        }
    }
    
    public boolean unhideFile(String filePath) {
        try {
            Path path = Paths.get(filePath);
            
            if (!Files.exists(path)) {
                logger.error("File does not exist: " + filePath);
                return false;
            }
            
            boolean success = false;
            
            if (isWindows()) {
                // On Windows, remove the hidden attribute
                Files.setAttribute(path, "dos:hidden", false);
                success = true;
                logger.info("File unhidden using DOS attribute: " + filePath);
            } else {
                // On Unix-like systems, remove the leading dot
                Path parent = path.getParent();
                String fileName = path.getFileName().toString();
                
                if (fileName.startsWith(".")) {
                    String unhiddenName = fileName.substring(1);
                    Path unhiddenPath = parent.resolve(unhiddenName);
                    Files.move(path, unhiddenPath);
                    success = true;
                    logger.info("File unhidden by renaming: " + filePath + " -> " + unhiddenPath);
                } else {
                    logger.warn("File is not hidden: " + filePath);
                    success = true;
                }
            }
            
            if (success) {
                // Remove from hidden files database
                removeHiddenFile(filePath);
            }
            
            return success;
            
        } catch (IOException e) {
            logger.error("Error unhiding file: " + filePath + " - " + e.getMessage());
            return false;
        }
    }
    
    public List<String> getHiddenFiles() {
        List<String> hiddenFiles = new ArrayList<>();
        
        try {
            Connection conn = DatabaseConnection.getInstance().getConnection();
            String sql = "SELECT file_path FROM hidden_files WHERE is_hidden = 1 ORDER BY hidden_at DESC";
            
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                ResultSet rs = stmt.executeQuery();
                
                while (rs.next()) {
                    String filePath = rs.getString("file_path");
                    // Verify file still exists and is actually hidden
                    if (Files.exists(Paths.get(filePath)) && isFileHidden(filePath)) {
                        hiddenFiles.add(filePath);
                    }
                }
            }
            
        } catch (SQLException e) {
            logger.error("Error retrieving hidden files: " + e.getMessage());
        }
        
        return hiddenFiles;
    }
    
    public boolean isFileHidden(String filePath) {
        try {
            Path path = Paths.get(filePath);
            
            if (!Files.exists(path)) {
                return false;
            }
            
            if (isWindows()) {
                DosFileAttributes attrs = Files.readAttributes(path, DosFileAttributes.class);
                return attrs.isHidden();
            } else {
                return path.getFileName().toString().startsWith(".");
            }
            
        } catch (IOException e) {
            logger.error("Error checking if file is hidden: " + filePath + " - " + e.getMessage());
            return false;
        }
    }
    
    private void recordHiddenFile(String filePath) {
        try {
            Connection conn = DatabaseConnection.getInstance().getConnection();
            String sql = "INSERT OR REPLACE INTO hidden_files (file_path, hidden_at, is_hidden) VALUES (?, ?, 1)";
            
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, filePath);
                stmt.setTimestamp(2, Timestamp.valueOf(LocalDateTime.now()));
                stmt.executeUpdate();
            }
            
        } catch (SQLException e) {
            logger.error("Error recording hidden file: " + e.getMessage());
        }
    }
    
    private void removeHiddenFile(String filePath) {
        try {
            Connection conn = DatabaseConnection.getInstance().getConnection();
            String sql = "UPDATE hidden_files SET is_hidden = 0, unhidden_at = ? WHERE file_path = ?";
            
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setTimestamp(1, Timestamp.valueOf(LocalDateTime.now()));
                stmt.setString(2, filePath);
                stmt.executeUpdate();
            }
            
        } catch (SQLException e) {
            logger.error("Error removing hidden file record: " + e.getMessage());
        }
    }
    
    private boolean isWindows() {
        return System.getProperty("os.name").toLowerCase().contains("windows");
    }
}
