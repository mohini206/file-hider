package com.filehider.database;

import com.filehider.utils.Logger;

import java.sql.*;

public class DatabaseConnection {
    private static final Logger logger = Logger.getInstance();
    private static DatabaseConnection instance;
    private Connection connection;
    
    private static final String DB_URL = "jdbc:sqlite:data/filehider.db";
    
    private DatabaseConnection() {}
    
    public static synchronized DatabaseConnection getInstance() {
        if (instance == null) {
            instance = new DatabaseConnection();
        }
        return instance;
    }
    
    public Connection getConnection() throws SQLException {
        if (connection == null || connection.isClosed()) {
            connection = DriverManager.getConnection(DB_URL);
        }
        return connection;
    }
    
    public void initializeDatabase() {
        try {
            // Create data directory if it doesn't exist
            java.io.File dataDir = new java.io.File("data");
            if (!dataDir.exists()) {
                dataDir.mkdirs();
            }
            
            Connection conn = getConnection();
            
            // Create users table
            String createUsersTable = """
                CREATE TABLE IF NOT EXISTS users (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL,
                    email TEXT UNIQUE NOT NULL,
                    password_hash TEXT NOT NULL,
                    salt TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    password_changed_at TIMESTAMP,
                    is_active INTEGER DEFAULT 1
                )
                """;
            
            // Create OTP codes table
            String createOtpTable = """
                CREATE TABLE IF NOT EXISTS otp_codes (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    email TEXT NOT NULL,
                    otp_code TEXT NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    expires_at TIMESTAMP NOT NULL,
                    used INTEGER DEFAULT 0,
                    used_at TIMESTAMP
                )
                """;
            
            // Create security log table
            String createSecurityLogTable = """
                CREATE TABLE IF NOT EXISTS security_log (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    email TEXT,
                    event_type TEXT NOT NULL,
                    description TEXT,
                    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    ip_address TEXT
                )
                """;
            
            // Create hidden files table
            String createHiddenFilesTable = """
                CREATE TABLE IF NOT EXISTS hidden_files (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    file_path TEXT UNIQUE NOT NULL,
                    hidden_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    unhidden_at TIMESTAMP,
                    is_hidden INTEGER DEFAULT 1
                )
                """;
            
            try (Statement stmt = conn.createStatement()) {
                stmt.execute(createUsersTable);
                stmt.execute(createOtpTable);
                stmt.execute(createSecurityLogTable);
                stmt.execute(createHiddenFilesTable);
            }
            
            logger.info("Database initialized successfully");
            
        } catch (SQLException e) {
            logger.error("Error initializing database: " + e.getMessage());
            throw new RuntimeException("Failed to initialize database", e);
        }
    }
    
    public void closeConnection() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
            }
        } catch (SQLException e) {
            logger.error("Error closing database connection: " + e.getMessage());
        }
    }
}
