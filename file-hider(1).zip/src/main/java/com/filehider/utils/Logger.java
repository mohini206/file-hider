package com.filehider.utils;

import java.io.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

public class Logger {
    private static Logger instance;
    private final BlockingQueue<LogEntry> logQueue;
    private final Thread loggerThread;
    private final PrintWriter logWriter;
    private final DateTimeFormatter formatter;
    
    private Logger() {
        logQueue = new LinkedBlockingQueue<>();
        formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        
        try {
            // Create logs directory if it doesn't exist
            File logsDir = new File("logs");
            if (!logsDir.exists()) {
                logsDir.mkdirs();
            }
            
            // Create log file with timestamp
            String logFileName = "logs/filehider_" + 
                LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss")) + ".log";
            logWriter = new PrintWriter(new FileWriter(logFileName, true));
            
        } catch (IOException e) {
            throw new RuntimeException("Failed to initialize logger", e);
        }
        
        // Start logger thread
        loggerThread = new Thread(this::processLogEntries);
        loggerThread.setDaemon(true);
        loggerThread.start();
    }
    
    public static synchronized Logger getInstance() {
        if (instance == null) {
            instance = new Logger();
        }
        return instance;
    }
    
    public void info(String message) {
        log(LogLevel.INFO, message);
    }
    
    public void warn(String message) {
        log(LogLevel.WARN, message);
    }
    
    public void error(String message) {
        log(LogLevel.ERROR, message);
    }
    
    public void debug(String message) {
        log(LogLevel.DEBUG, message);
    }
    
    private void log(LogLevel level, String message) {
        LogEntry entry = new LogEntry(level, message, LocalDateTime.now());
        logQueue.offer(entry);
    }
    
    private void processLogEntries() {
        while (true) {
            try {
                LogEntry entry = logQueue.take();
                String formattedMessage = String.format("[%s] %s - %s",
                    entry.timestamp.format(formatter),
                    entry.level,
                    entry.message);
                
                // Write to file
                logWriter.println(formattedMessage);
                logWriter.flush();
                
                // Also print to console
                System.out.println(formattedMessage);
                
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                break;
            }
        }
    }
    
    public void shutdown() {
        loggerThread.interrupt();
        if (logWriter != null) {
            logWriter.close();
        }
    }
    
    private static class LogEntry {
        final LogLevel level;
        final String message;
        final LocalDateTime timestamp;
        
        LogEntry(LogLevel level, String message, LocalDateTime timestamp) {
            this.level = level;
            this.message = message;
            this.timestamp = timestamp;
        }
    }
    
    private enum LogLevel {
        DEBUG, INFO, WARN, ERROR
    }
}
