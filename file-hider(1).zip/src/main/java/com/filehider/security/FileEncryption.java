package com.filehider.security;

import com.filehider.utils.Logger;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.SecureRandom;
import java.util.Base64;

public class FileEncryption {
    private static final Logger logger = Logger.getInstance();
    
    public boolean encryptFile(String filePath, String key, String algorithm) {
        try {
            File inputFile = new File(filePath);
            if (!inputFile.exists()) {
                logger.error("File does not exist: " + filePath);
                return false;
            }
            
            // Read file content
            byte[] fileContent = Files.readAllBytes(Paths.get(filePath));
            
            // Encrypt content
            byte[] encryptedContent = encrypt(fileContent, key, algorithm);
            
            if (encryptedContent != null) {
                // Write encrypted content to new file
                String encryptedFilePath = filePath + ".enc";
                Files.write(Paths.get(encryptedFilePath), encryptedContent);
                
                // Securely delete original file
                secureDelete(filePath);
                
                logger.info("File encrypted successfully: " + filePath);
                return true;
            }
            
        } catch (Exception e) {
            logger.error("Error encrypting file: " + e.getMessage());
        }
        
        return false;
    }
    
    public boolean decryptFile(String filePath, String key, String algorithm) {
        try {
            File inputFile = new File(filePath);
            if (!inputFile.exists()) {
                logger.error("File does not exist: " + filePath);
                return false;
            }
            
            // Read encrypted content
            byte[] encryptedContent = Files.readAllBytes(Paths.get(filePath));
            
            // Decrypt content
            byte[] decryptedContent = decrypt(encryptedContent, key, algorithm);
            
            if (decryptedContent != null) {
                // Write decrypted content to new file
                String decryptedFilePath = filePath.replace(".enc", "");
                Files.write(Paths.get(decryptedFilePath), decryptedContent);
                
                // Delete encrypted file
                Files.delete(Paths.get(filePath));
                
                logger.info("File decrypted successfully: " + filePath);
                return true;
            }
            
        } catch (Exception e) {
            logger.error("Error decrypting file: " + e.getMessage());
        }
        
        return false;
    }
    
    private byte[] encrypt(byte[] data, String key, String algorithm) {
        try {
            String transformation = getTransformation(algorithm);
            Cipher cipher = Cipher.getInstance(transformation);
            
            SecretKeySpec secretKey = new SecretKeySpec(key.getBytes(), getAlgorithmName(algorithm));
            cipher.init(Cipher.ENCRYPT_MODE, secretKey);
            
            return cipher.doFinal(data);
            
        } catch (Exception e) {
            logger.error("Error during encryption: " + e.getMessage());
            return null;
        }
    }
    
    private byte[] decrypt(byte[] encryptedData, String key, String algorithm) {
        try {
            String transformation = getTransformation(algorithm);
            Cipher cipher = Cipher.getInstance(transformation);
            
            SecretKeySpec secretKey = new SecretKeySpec(key.getBytes(), getAlgorithmName(algorithm));
            cipher.init(Cipher.DECRYPT_MODE, secretKey);
            
            return cipher.doFinal(encryptedData);
            
        } catch (Exception e) {
            logger.error("Error during decryption: " + e.getMessage());
            return null;
        }
    }
    
    private String getTransformation(String algorithm) {
        switch (algorithm) {
            case "AES-256":
            case "AES-128":
                return "AES";
            case "DES":
                return "DES";
            default:
                return "AES";
        }
    }
    
    private String getAlgorithmName(String algorithm) {
        switch (algorithm) {
            case "AES-256":
            case "AES-128":
                return "AES";
            case "DES":
                return "DES";
            default:
                return "AES";
        }
    }
    
    public String generateRandomKey() {
        try {
            KeyGenerator keyGenerator = KeyGenerator.getInstance("AES");
            keyGenerator.init(256);
            SecretKey secretKey = keyGenerator.generateKey();
            
            return Base64.getEncoder().encodeToString(secretKey.getEncoded());
            
        } catch (Exception e) {
            logger.error("Error generating random key: " + e.getMessage());
            
            // Fallback: generate random string
            SecureRandom random = new SecureRandom();
            byte[] keyBytes = new byte[32]; // 256-bit key
            random.nextBytes(keyBytes);
            return Base64.getEncoder().encodeToString(keyBytes);
        }
    }
    
    public boolean secureDelete(String filePath) {
        try {
            File file = new File(filePath);
            if (!file.exists()) {
                return false;
            }
            
            long fileSize = file.length();
            
            // Overwrite file content multiple times
            try (RandomAccessFile raf = new RandomAccessFile(file, "rws")) {
                SecureRandom random = new SecureRandom();
                
                // Perform 3 overwrite passes
                for (int pass = 0; pass < 3; pass++) {
                    raf.seek(0);
                    
                    byte[] buffer = new byte[8192];
                    long remaining = fileSize;
                    
                    while (remaining > 0) {
                        int bytesToWrite = (int) Math.min(buffer.length, remaining);
                        random.nextBytes(buffer);
                        raf.write(buffer, 0, bytesToWrite);
                        remaining -= bytesToWrite;
                    }
                    
                    raf.getFD().sync(); // Force write to disk
                }
            }
            
            // Delete the file
            boolean deleted = file.delete();
            if (deleted) {
                logger.info("File securely deleted: " + filePath);
            }
            
            return deleted;
            
        } catch (Exception e) {
            logger.error("Error securely deleting file: " + e.getMessage());
            return false;
        }
    }
}
