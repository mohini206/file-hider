package com.filehider.security;

import com.filehider.database.DatabaseConnection;
import com.filehider.utils.Logger;

import javax.mail.*;
import javax.mail.internet.*;
import java.security.SecureRandom;
import java.sql.*;
import java.time.LocalDateTime;
import java.util.Properties;

public class EmailService {
    private static final Logger logger = Logger.getInstance();
    
    // Email configuration - In production, use environment variables
    private static final String SMTP_HOST = "smtp.gmail.com";
    private static final String SMTP_PORT = "587";
    private static final String EMAIL_USERNAME = "your-email@gmail.com";
    private static final String EMAIL_PASSWORD = "your-app-password";
    
    public boolean sendOTP(String userEmail) {
        try {
            String otp = generateOTP();
            
            // Store OTP in database
            if (storeOTP(userEmail, otp)) {
                // Send email
                return sendOTPEmail(userEmail, otp);
            }
            
        } catch (Exception e) {
            logger.error("Error sending OTP: " + e.getMessage());
        }
        
        return false;
    }
    
    public boolean verifyOTP(String email, String otp) {
        try {
            Connection conn = DatabaseConnection.getInstance().getConnection();
            String sql = "SELECT otp_code FROM otp_codes WHERE email = ? AND otp_code = ? AND expires_at > ? AND used = 0";
            
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, email);
                stmt.setString(2, otp);
                stmt.setTimestamp(3, Timestamp.valueOf(LocalDateTime.now()));
                
                ResultSet rs = stmt.executeQuery();
                if (rs.next()) {
                    // Mark OTP as used
                    markOTPAsUsed(email, otp);
                    logger.info("OTP verified successfully for: " + email);
                    return true;
                }
            }
            
        } catch (SQLException e) {
            logger.error("Database error during OTP verification: " + e.getMessage());
        }
        
        logger.warn("OTP verification failed for: " + email);
        return false;
    }
    
    private String generateOTP() {
        SecureRandom random = new SecureRandom();
        int otp = 100000 + random.nextInt(900000); // 6-digit OTP
        return String.valueOf(otp);
    }
    
    private boolean storeOTP(String email, String otp) {
        try {
            Connection conn = DatabaseConnection.getInstance().getConnection();
            
            // First, invalidate any existing OTPs for this email
            String invalidateSQL = "UPDATE otp_codes SET used = 1 WHERE email = ? AND used = 0";
            try (PreparedStatement stmt = conn.prepareStatement(invalidateSQL)) {
                stmt.setString(1, email);
                stmt.executeUpdate();
            }
            
            // Insert new OTP
            String sql = "INSERT INTO otp_codes (email, otp_code, created_at, expires_at, used) VALUES (?, ?, ?, ?, 0)";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, email);
                stmt.setString(2, otp);
                stmt.setTimestamp(3, Timestamp.valueOf(LocalDateTime.now()));
                stmt.setTimestamp(4, Timestamp.valueOf(LocalDateTime.now().plusMinutes(5))); // 5-minute expiry
                
                int rowsAffected = stmt.executeUpdate();
                return rowsAffected > 0;
            }
            
        } catch (SQLException e) {
            logger.error("Error storing OTP: " + e.getMessage());
            return false;
        }
    }
    
    private void markOTPAsUsed(String email, String otp) {
        try {
            Connection conn = DatabaseConnection.getInstance().getConnection();
            String sql = "UPDATE otp_codes SET used = 1, used_at = ? WHERE email = ? AND otp_code = ?";
            
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setTimestamp(1, Timestamp.valueOf(LocalDateTime.now()));
                stmt.setString(2, email);
                stmt.setString(3, otp);
                stmt.executeUpdate();
            }
            
        } catch (SQLException e) {
            logger.error("Error marking OTP as used: " + e.getMessage());
        }
    }
    
    private boolean sendOTPEmail(String userEmail, String otp) {
        try {
            Properties props = new Properties();
            props.put("mail.smtp.auth", "true");
            props.put("mail.smtp.starttls.enable", "true");
            props.put("mail.smtp.host", SMTP_HOST);
            props.put("mail.smtp.port", SMTP_PORT);
            
            Session session = Session.getInstance(props, new Authenticator() {
                @Override
                protected PasswordAuthentication getPasswordAuthentication() {
                    return new PasswordAuthentication(EMAIL_USERNAME, EMAIL_PASSWORD);
                }
            });
            
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(EMAIL_USERNAME));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(userEmail));
            message.setSubject("🔒 File Hider - Your OTP Code");
            
            String emailContent = String.format("""
                <html>
                <body style="font-family: Arial, sans-serif; background-color: #f4f4f4; padding: 20px;">
                    <div style="max-width: 600px; margin: 0 auto; background-color: white; padding: 30px; border-radius: 10px; box-shadow: 0 0 10px rgba(0,0,0,0.1);">
                        <h2 style="color: #333; text-align: center;">🔒 Secure File Hider</h2>
                        <h3 style="color: #007bff;">Your OTP Code</h3>
                        <p>Hello,</p>
                        <p>You have requested to access the Secure File Hider application. Please use the following OTP code to complete your login:</p>
                        <div style="background-color: #f8f9fa; padding: 20px; text-align: center; border-radius: 5px; margin: 20px 0;">
                            <h1 style="color: #28a745; font-size: 36px; margin: 0; letter-spacing: 3px;">%s</h1>
                        </div>
                        <p><strong>Important:</strong></p>
                        <ul>
                            <li>This OTP is valid for 5 minutes only</li>
                            <li>Do not share this code with anyone</li>
                            <li>If you didn't request this code, please ignore this email</li>
                        </ul>
                        <p>Thank you for using Secure File Hider!</p>
                        <hr style="border: none; border-top: 1px solid #eee; margin: 20px 0;">
                        <p style="font-size: 12px; color: #666; text-align: center;">
                            This is an automated message. Please do not reply to this email.
                        </p>
                    </div>
                </body>
                </html>
                """, otp);
            
            message.setContent(emailContent, "text/html");
            
            Transport.send(message);
            logger.info("OTP email sent successfully to: " + userEmail);
            return true;
            
        } catch (MessagingException e) {
            logger.error("Error sending OTP email: " + e.getMessage());
            return false;
        }
    }
}
