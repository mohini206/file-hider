package com.filehider.security;

import com.filehider.database.DatabaseConnection;
import com.filehider.utils.Logger;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.sql.*;
import java.time.LocalDateTime;

public class AuthenticationManager {
    private static final Logger logger = Logger.getInstance();
    
    public boolean authenticateUser(String email, String password) {
        try {
            String hashedPassword = hashPassword(password);
            
            Connection conn = DatabaseConnection.getInstance().getConnection();
            String sql = "SELECT id, name FROM users WHERE email = ? AND password_hash = ? AND is_active = 1";
            
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, email);
                stmt.setString(2, hashedPassword);
                
                ResultSet rs = stmt.executeQuery();
                if (rs.next()) {
                    // Log successful authentication
                    logSecurityEvent(email, "LOGIN_SUCCESS", "User authenticated successfully");
                    logger.info("User authenticated successfully: " + email);
                    return true;
                }
            }
            
        } catch (SQLException e) {
            logger.error("Database error during authentication: " + e.getMessage());
        }
        
        // Log failed authentication
        logSecurityEvent(email, "LOGIN_FAILED", "Invalid credentials");
        logger.warn("Authentication failed for user: " + email);
        return false;
    }
    
    public boolean registerUser(String name, String email, String password) {
        try {
            // Check if user already exists
            if (userExists(email)) {
                logger.warn("Registration attempt for existing user: " + email);
                return false;
            }
            
            String hashedPassword = hashPassword(password);
            String salt = generateSalt();
            
            Connection conn = DatabaseConnection.getInstance().getConnection();
            String sql = "INSERT INTO users (name, email, password_hash, salt, created_at, is_active) VALUES (?, ?, ?, ?, ?, 1)";
            
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, name);
                stmt.setString(2, email);
                stmt.setString(3, hashedPassword);
                stmt.setString(4, salt);
                stmt.setTimestamp(5, Timestamp.valueOf(LocalDateTime.now()));
                
                int rowsAffected = stmt.executeUpdate();
                if (rowsAffected > 0) {
                    logSecurityEvent(email, "USER_REGISTERED", "New user registered");
                    logger.info("User registered successfully: " + email);
                    return true;
                }
            }
            
        } catch (SQLException e) {
            logger.error("Database error during user registration: " + e.getMessage());
        }
        
        return false;
    }
    
    public boolean changePassword(String email, String oldPassword, String newPassword) {
        try {
            // First verify old password
            if (!authenticateUser(email, oldPassword)) {
                return false;
            }
            
            String hashedNewPassword = hashPassword(newPassword);
            
            Connection conn = DatabaseConnection.getInstance().getConnection();
            String sql = "UPDATE users SET password_hash = ?, password_changed_at = ? WHERE email = ?";
            
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, hashedNewPassword);
                stmt.setTimestamp(2, Timestamp.valueOf(LocalDateTime.now()));
                stmt.setString(3, email);
                
                int rowsAffected = stmt.executeUpdate();
                if (rowsAffected > 0) {
                    logSecurityEvent(email, "PASSWORD_CHANGED", "User changed password");
                    logger.info("Password changed for user: " + email);
                    return true;
                }
            }
            
        } catch (SQLException e) {
            logger.error("Database error during password change: " + e.getMessage());
        }
        
        return false;
    }
    
    private boolean userExists(String email) {
        try {
            Connection conn = DatabaseConnection.getInstance().getConnection();
            String sql = "SELECT id FROM users WHERE email = ?";
            
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, email);
                ResultSet rs = stmt.executeQuery();
                return rs.next();
            }
            
        } catch (SQLException e) {
            logger.error("Error checking if user exists: " + e.getMessage());
            return false;
        }
    }
    
    private String hashPassword(String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hashedBytes = md.digest(password.getBytes());
            
            StringBuilder sb = new StringBuilder();
            for (byte b : hashedBytes) {
                sb.append(String.format("%02x", b));
            }
            
            return sb.toString();
            
        } catch (NoSuchAlgorithmException e) {
            logger.error("Error hashing password: " + e.getMessage());
            return null;
        }
    }
    
    private String generateSalt() {
        SecureRandom random = new SecureRandom();
        byte[] salt = new byte[16];
        random.nextBytes(salt);
        
        StringBuilder sb = new StringBuilder();
        for (byte b : salt) {
            sb.append(String.format("%02x", b));
        }
        
        return sb.toString();
    }
    
    private void logSecurityEvent(String email, String eventType, String description) {
        try {
            Connection conn = DatabaseConnection.getInstance().getConnection();
            String sql = "INSERT INTO security_log (email, event_type, description, timestamp, ip_address) VALUES (?, ?, ?, ?, ?)";
            
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, email);
                stmt.setString(2, eventType);
                stmt.setString(3, description);
                stmt.setTimestamp(4, Timestamp.valueOf(LocalDateTime.now()));
                stmt.setString(5, getClientIP());
                
                stmt.executeUpdate();
            }
            
        } catch (SQLException e) {
            logger.error("Error logging security event: " + e.getMessage());
        }
    }
    
    private String getClientIP() {
        // In a real application, you would get the actual client IP
        return "127.0.0.1";
    }
}
