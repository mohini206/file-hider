package com.filehider;

import com.filehider.gui.LoginFrame;
import com.filehider.database.DatabaseConnection;
import com.filehider.utils.Logger;

import javax.swing.*;

public class FileHiderApplication {
    private static final Logger logger = Logger.getInstance();
    
    public static void main(String[] args) {
        try {
            // Set system look and feel
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeel());
            
            logger.info("Starting File Hider Security Application...");
            
            // Initialize database
            DatabaseConnection.getInstance().initializeDatabase();
            
            // Show login frame
            SwingUtilities.invokeLater(() -> {
                new LoginFrame().setVisible(true);
            });
            
        } catch (Exception e) {
            logger.error("Failed to start application: " + e.getMessage());
            JOptionPane.showMessageDialog(null, 
                "Failed to start application: " + e.getMessage(), 
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
