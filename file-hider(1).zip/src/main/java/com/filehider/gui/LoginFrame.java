package com.filehider.gui;

import com.filehider.security.AuthenticationManager;
import com.filehider.security.EmailService;
import com.filehider.utils.Logger;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LoginFrame extends JFrame {
    private static final Logger logger = Logger.getInstance();
    
    private JTextField emailField;
    private JPasswordField passwordField;
    private JTextField otpField;
    private JButton loginButton;
    private JButton registerButton;
    private JButton sendOtpButton;
    private JButton verifyOtpButton;
    private JLabel statusLabel;
    
    private AuthenticationManager authManager;
    private EmailService emailService;
    private String currentEmail;
    
    public LoginFrame() {
        authManager = new AuthenticationManager();
        emailService = new EmailService();
        initializeGUI();
    }
    
    private void initializeGUI() {
        setTitle("File Hider - Secure Login");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
        
        // Create main panel
        JPanel mainPanel = new JPanel(new GridBagLayout());
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        mainPanel.setBackground(new Color(45, 45, 45));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        
        // Title
        JLabel titleLabel = new JLabel("🔒 SECURE FILE HIDER");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 3;
        mainPanel.add(titleLabel, gbc);
        
        // Email field
        gbc.gridwidth = 1;
        gbc.gridx = 0; gbc.gridy = 1;
        JLabel emailLabel = new JLabel("Email:");
        emailLabel.setForeground(Color.WHITE);
        mainPanel.add(emailLabel, gbc);
        
        gbc.gridx = 1; gbc.gridwidth = 2; gbc.fill = GridBagConstraints.HORIZONTAL;
        emailField = new JTextField(20);
        emailField.setFont(new Font("Arial", Font.PLAIN, 14));
        mainPanel.add(emailField, gbc);
        
        // Password field
        gbc.gridwidth = 1; gbc.fill = GridBagConstraints.NONE;
        gbc.gridx = 0; gbc.gridy = 2;
        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setForeground(Color.WHITE);
        mainPanel.add(passwordLabel, gbc);
        
        gbc.gridx = 1; gbc.gridwidth = 2; gbc.fill = GridBagConstraints.HORIZONTAL;
        passwordField = new JPasswordField(20);
        passwordField.setFont(new Font("Arial", Font.PLAIN, 14));
        mainPanel.add(passwordField, gbc);
        
        // OTP field
        gbc.gridwidth = 1; gbc.fill = GridBagConstraints.NONE;
        gbc.gridx = 0; gbc.gridy = 3;
        JLabel otpLabel = new JLabel("OTP:");
        otpLabel.setForeground(Color.WHITE);
        mainPanel.add(otpLabel, gbc);
        
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL;
        otpField = new JTextField(10);
        otpField.setFont(new Font("Arial", Font.PLAIN, 14));
        otpField.setEnabled(false);
        mainPanel.add(otpField, gbc);
        
        gbc.gridx = 2; gbc.fill = GridBagConstraints.NONE;
        sendOtpButton = new JButton("Send OTP");
        sendOtpButton.setBackground(new Color(0, 123, 255));
        sendOtpButton.setForeground(Color.WHITE);
        sendOtpButton.setEnabled(false);
        mainPanel.add(sendOtpButton, gbc);
        
        // Buttons panel
        JPanel buttonPanel = new JPanel(new FlowLayout());
        buttonPanel.setBackground(new Color(45, 45, 45));
        
        loginButton = new JButton("Login");
        loginButton.setBackground(new Color(40, 167, 69));
        loginButton.setForeground(Color.WHITE);
        loginButton.setPreferredSize(new Dimension(100, 35));
        
        registerButton = new JButton("Register");
        registerButton.setBackground(new Color(108, 117, 125));
        registerButton.setForeground(Color.WHITE);
        registerButton.setPreferredSize(new Dimension(100, 35));
        
        verifyOtpButton = new JButton("Verify OTP");
        verifyOtpButton.setBackground(new Color(255, 193, 7));
        verifyOtpButton.setForeground(Color.BLACK);
        verifyOtpButton.setPreferredSize(new Dimension(100, 35));
        verifyOtpButton.setEnabled(false);
        
        buttonPanel.add(loginButton);
        buttonPanel.add(registerButton);
        buttonPanel.add(verifyOtpButton);
        
        gbc.gridx = 0; gbc.gridy = 4; gbc.gridwidth = 3;
        mainPanel.add(buttonPanel, gbc);
        
        // Status label
        statusLabel = new JLabel("Enter your credentials to continue");
        statusLabel.setForeground(Color.LIGHT_GRAY);
        statusLabel.setHorizontalAlignment(SwingConstants.CENTER);
        gbc.gridy = 5;
        mainPanel.add(statusLabel, gbc);
        
        add(mainPanel, BorderLayout.CENTER);
        
        // Event listeners
        setupEventListeners();
        
        pack();
        setLocationRelativeTo(null);
        setResizable(false);
    }
    
    private void setupEventListeners() {
        loginButton.addActionListener(e -> performLogin());
        registerButton.addActionListener(e -> showRegistrationDialog());
        sendOtpButton.addActionListener(e -> sendOTP());
        verifyOtpButton.addActionListener(e -> verifyOTP());
        
        // Enable/disable OTP button based on email input
        emailField.addActionListener(e -> {
            String email = emailField.getText().trim();
            sendOtpButton.setEnabled(!email.isEmpty() && isValidEmail(email));
        });
    }
    
    private void performLogin() {
        String email = emailField.getText().trim();
        String password = new String(passwordField.getPassword());
        
        if (email.isEmpty() || password.isEmpty()) {
            updateStatus("Please fill in all fields", Color.RED);
            return;
        }
        
        if (!isValidEmail(email)) {
            updateStatus("Please enter a valid email address", Color.RED);
            return;
        }
        
        // Perform authentication
        SwingWorker<Boolean, Void> worker = new SwingWorker<Boolean, Void>() {
            @Override
            protected Boolean doInBackground() throws Exception {
                updateStatus("Authenticating...", Color.YELLOW);
                return authManager.authenticateUser(email, password);
            }
            
            @Override
            protected void done() {
                try {
                    boolean authenticated = get();
                    if (authenticated) {
                        currentEmail = email;
                        updateStatus("Authentication successful! Please verify OTP.", Color.GREEN);
                        enableOTPVerification();
                    } else {
                        updateStatus("Invalid credentials!", Color.RED);
                    }
                } catch (Exception e) {
                    updateStatus("Authentication error: " + e.getMessage(), Color.RED);
                }
            }
        };
        worker.execute();
    }
    
    private void sendOTP() {
        String email = emailField.getText().trim();
        
        SwingWorker<Boolean, Void> worker = new SwingWorker<Boolean, Void>() {
            @Override
            protected Boolean doInBackground() throws Exception {
                updateStatus("Sending OTP...", Color.YELLOW);
                return emailService.sendOTP(email);
            }
            
            @Override
            protected void done() {
                try {
                    boolean sent = get();
                    if (sent) {
                        updateStatus("OTP sent to your email!", Color.GREEN);
                        otpField.setEnabled(true);
                        verifyOtpButton.setEnabled(true);
                    } else {
                        updateStatus("Failed to send OTP", Color.RED);
                    }
                } catch (Exception e) {
                    updateStatus("Error sending OTP: " + e.getMessage(), Color.RED);
                }
            }
        };
        worker.execute();
    }
    
    private void verifyOTP() {
        String otp = otpField.getText().trim();
        
        if (otp.isEmpty()) {
            updateStatus("Please enter OTP", Color.RED);
            return;
        }
        
        SwingWorker<Boolean, Void> worker = new SwingWorker<Boolean, Void>() {
            @Override
            protected Boolean doInBackground() throws Exception {
                updateStatus("Verifying OTP...", Color.YELLOW);
                return emailService.verifyOTP(currentEmail, otp);
            }
            
            @Override
            protected void done() {
                try {
                    boolean verified = get();
                    if (verified) {
                        updateStatus("Login successful!", Color.GREEN);
                        openMainApplication();
                    } else {
                        updateStatus("Invalid OTP!", Color.RED);
                    }
                } catch (Exception e) {
                    updateStatus("OTP verification error: " + e.getMessage(), Color.RED);
                }
            }
        };
        worker.execute();
    }
    
    private void enableOTPVerification() {
        sendOtpButton.setEnabled(true);
        loginButton.setEnabled(false);
    }
    
    private void openMainApplication() {
        SwingUtilities.invokeLater(() -> {
            new MainFrame(currentEmail).setVisible(true);
            dispose();
        });
    }
    
    private void showRegistrationDialog() {
        new RegistrationDialog(this).setVisible(true);
    }
    
    private boolean isValidEmail(String email) {
        return email.matches("^[A-Za-z0-9+_.-]+@(.+)$");
    }
    
    private void updateStatus(String message, Color color) {
        SwingUtilities.invokeLater(() -> {
            statusLabel.setText(message);
            statusLabel.setForeground(color);
        });
    }
}
