package com.filehider.gui;

import com.filehider.core.*;
import com.filehider.utils.Logger;

import javax.swing.*;
import java.awt.*;

public class MainFrame extends JFrame {
    private static final Logger logger = Logger.getInstance();
    
    private String currentUser;
    private JTabbedPane tabbedPane;
    private FileHiderPanel fileHiderPanel;
    private EncryptionPanel encryptionPanel;
    private SecurityPanel securityPanel;
    
    public MainFrame(String userEmail) {
        this.currentUser = userEmail;
        initializeGUI();
        logger.info("Main application opened for user: " + userEmail);
    }
    
    private void initializeGUI() {
        setTitle("🔒 Secure File Hider - " + currentUser);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
        
        // Create tabbed pane
        tabbedPane = new JTabbedPane();
        tabbedPane.setBackground(new Color(45, 45, 45));
        tabbedPane.setForeground(Color.WHITE);
        
        // Initialize panels
        fileHiderPanel = new FileHiderPanel();
        encryptionPanel = new EncryptionPanel();
        securityPanel = new SecurityPanel(currentUser);
        
        // Add tabs with icons
        tabbedPane.addTab("🗂️ File Hider", fileHiderPanel);
        tabbedPane.addTab("🔐 Encryption", encryptionPanel);
        tabbedPane.addTab("🛡️ Security", securityPanel);
        
        // Menu bar
        setupMenuBar();
        
        // Status bar
        JLabel statusBar = new JLabel("Welcome, " + currentUser + " | Secure File Management System");
        statusBar.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
        statusBar.setBackground(new Color(33, 37, 41));
        statusBar.setForeground(Color.WHITE);
        statusBar.setOpaque(true);
        
        add(tabbedPane, BorderLayout.CENTER);
        add(statusBar, BorderLayout.SOUTH);
        
        setSize(1000, 700);
        setLocationRelativeTo(null);
        
        // Set dark theme
        getContentPane().setBackground(new Color(45, 45, 45));
    }
    
    private void setupMenuBar() {
        JMenuBar menuBar = new JMenuBar();
        menuBar.setBackground(new Color(33, 37, 41));
        
        // File menu
        JMenu fileMenu = new JMenu("File");
        fileMenu.setForeground(Color.WHITE);
        
        JMenuItem logoutItem = new JMenuItem("Logout");
        logoutItem.addActionListener(e -> logout());
        
        JMenuItem exitItem = new JMenuItem("Exit");
        exitItem.addActionListener(e -> System.exit(0));
        
        fileMenu.add(logoutItem);
        fileMenu.addSeparator();
        fileMenu.add(exitItem);
        
        // Security menu
        JMenu securityMenu = new JMenu("Security");
        securityMenu.setForeground(Color.WHITE);
        
        JMenuItem changePasswordItem = new JMenuItem("Change Password");
        changePasswordItem.addActionListener(e -> showChangePasswordDialog());
        
        JMenuItem securityLogItem = new JMenuItem("View Security Log");
        securityLogItem.addActionListener(e -> showSecurityLog());
        
        securityMenu.add(changePasswordItem);
        securityMenu.add(securityLogItem);
        
        // Help menu
        JMenu helpMenu = new JMenu("Help");
        helpMenu.setForeground(Color.WHITE);
        
        JMenuItem aboutItem = new JMenuItem("About");
        aboutItem.addActionListener(e -> showAboutDialog());
        
        helpMenu.add(aboutItem);
        
        menuBar.add(fileMenu);
        menuBar.add(securityMenu);
        menuBar.add(helpMenu);
        
        setJMenuBar(menuBar);
    }
    
    private void logout() {
        int result = JOptionPane.showConfirmDialog(this,
            "Are you sure you want to logout?",
            "Logout Confirmation",
            JOptionPane.YES_NO_OPTION);
        
        if (result == JOptionPane.YES_OPTION) {
            logger.info("User logged out: " + currentUser);
            dispose();
            new LoginFrame().setVisible(true);
        }
    }
    
    private void showChangePasswordDialog() {
        new ChangePasswordDialog(this, currentUser).setVisible(true);
    }
    
    private void showSecurityLog() {
        new SecurityLogDialog(this, currentUser).setVisible(true);
    }
    
    private void showAboutDialog() {
        String aboutText = """
            🔒 Secure File Hider v2.0
            
            Features:
            • Advanced file hiding with encryption
            • Email-based OTP authentication
            • Secure file operations
            • Activity logging and monitoring
            
            Developed with Java & MySQL
            Security-first approach
            """;
        
        JOptionPane.showMessageDialog(this, aboutText, "About", JOptionPane.INFORMATION_MESSAGE);
    }
}
