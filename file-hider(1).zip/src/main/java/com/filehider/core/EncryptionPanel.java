package com.filehider.core;

import com.filehider.security.FileEncryption;
import com.filehider.utils.Logger;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import java.awt.*;
import java.io.File;
import java.util.List;

public class EncryptionPanel extends JPanel {
    private static final Logger logger = Logger.getInstance();
    
    private JTextField filePathField;
    private JPasswordField encryptionKeyField;
    private JTextArea outputArea;
    private JProgressBar progressBar;
    private JComboBox<String> algorithmComboBox;
    
    private FileEncryption fileEncryption;
    
    public EncryptionPanel() {
        fileEncryption = new FileEncryption();
        initializeComponents();
        layoutComponents();
    }
    
    private void initializeComponents() {
        setBackground(new Color(45, 45, 45));
        
        filePathField = new JTextField(40);
        filePathField.setFont(new Font("Arial", Font.PLAIN, 14));
        
        encryptionKeyField = new JPasswordField(20);
        encryptionKeyField.setFont(new Font("Arial", Font.PLAIN, 14));
        
        algorithmComboBox = new JComboBox<>(new String[]{"AES-256", "AES-128", "DES"});
        algorithmComboBox.setSelectedIndex(0);
        
        outputArea = new JTextArea(15, 50);
        outputArea.setEditable(false);
        outputArea.setFont(new Font("Consolas", Font.PLAIN, 12));
        outputArea.setBackground(new Color(33, 37, 41));
        outputArea.setForeground(Color.WHITE);
        outputArea.setText("🔐 File Encryption System Ready\n" +
                          "Select a file and enter encryption key...\n\n");
        
        progressBar = new JProgressBar();
        progressBar.setStringPainted(true);
        progressBar.setBackground(new Color(33, 37, 41));
        progressBar.setForeground(new Color(40, 167, 69));
    }
    
    private void layoutComponents() {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // Top panel - File and key selection
        JPanel topPanel = new JPanel(new GridBagLayout());
        topPanel.setBackground(new Color(45, 45, 45));
        topPanel.setBorder(createTitledBorder("🔐 Encryption Settings"));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        
        // File selection
        gbc.gridx = 0; gbc.gridy = 0; gbc.anchor = GridBagConstraints.WEST;
        JLabel fileLabel = new JLabel("File:");
        fileLabel.setForeground(Color.WHITE);
        topPanel.add(fileLabel, gbc);
        
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        topPanel.add(filePathField, gbc);
        
        gbc.gridx = 2; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        JButton browseButton = createStyledButton("Browse", new Color(0, 123, 255));
        browseButton.addActionListener(e -> browseFile());
        topPanel.add(browseButton, gbc);
        
        // Encryption key
        gbc.gridx = 0; gbc.gridy = 1; gbc.anchor = GridBagConstraints.WEST;
        JLabel keyLabel = new JLabel("Encryption Key:");
        keyLabel.setForeground(Color.WHITE);
        topPanel.add(keyLabel, gbc);
        
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        topPanel.add(encryptionKeyField, gbc);
        
        gbc.gridx = 2; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        JButton generateKeyButton = createStyledButton("Generate", new Color(255, 193, 7));
        generateKeyButton.addActionListener(e -> generateRandomKey());
        topPanel.add(generateKeyButton, gbc);
        
        // Algorithm selection
        gbc.gridx = 0; gbc.gridy = 2; gbc.anchor = GridBagConstraints.WEST;
        JLabel algorithmLabel = new JLabel("Algorithm:");
        algorithmLabel.setForeground(Color.WHITE);
        topPanel.add(algorithmLabel, gbc);
        
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL;
        topPanel.add(algorithmComboBox, gbc);
        
        // Center panel - Operations and output
        JPanel centerPanel = new JPanel(new BorderLayout(10, 10));
        centerPanel.setBackground(new Color(45, 45, 45));
        
        // Operations panel
        JPanel operationsPanel = new JPanel(new FlowLayout());
        operationsPanel.setBackground(new Color(45, 45, 45));
        operationsPanel.setBorder(createTitledBorder("🔧 Encryption Operations"));
        
        JButton encryptButton = createStyledButton("🔒 Encrypt File", new Color(220, 53, 69));
        encryptButton.addActionListener(e -> encryptFile());
        
        JButton decryptButton = createStyledButton("🔓 Decrypt File", new Color(40, 167, 69));
        decryptButton.addActionListener(e -> decryptFile());
        
        JButton secureDeleteButton = createStyledButton("🗑️ Secure Delete", new Color(108, 117, 125));
        secureDeleteButton.addActionListener(e -> secureDeleteFile());
        
        JButton clearLogButton = createStyledButton("📋 Clear Log", new Color(255, 193, 7));
        clearLogButton.addActionListener(e -> outputArea.setText("Log cleared.\n"));
        
        operationsPanel.add(encryptButton);
        operationsPanel.add(decryptButton);
        operationsPanel.add(secureDeleteButton);
        operationsPanel.add(clearLogButton);
        
        // Output panel
        JScrollPane outputScrollPane = new JScrollPane(outputArea);
        outputScrollPane.setBorder(createTitledBorder("📋 Encryption Log"));
        
        centerPanel.add(operationsPanel, BorderLayout.NORTH);
        centerPanel.add(outputScrollPane, BorderLayout.CENTER);
        centerPanel.add(progressBar, BorderLayout.SOUTH);
        
        add(topPanel, BorderLayout.NORTH);
        add(centerPanel, BorderLayout.CENTER);
    }
    
    private TitledBorder createTitledBorder(String title) {
        TitledBorder border = BorderFactory.createTitledBorder(title);
        border.setTitleColor(Color.WHITE);
        return border;
    }
    
    private JButton createStyledButton(String text, Color backgroundColor) {
        JButton button = new JButton(text);
        button.setBackground(backgroundColor);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setPreferredSize(new Dimension(140, 35));
        button.setFont(new Font("Arial", Font.BOLD, 12));
        return button;
    }
    
    private void browseFile() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
        
        int result = fileChooser.showOpenDialog(this);
        if (result == JFileChooser.APPROVE_OPTION) {
            File selectedFile = fileChooser.getSelectedFile();
            filePathField.setText(selectedFile.getAbsolutePath());
            appendOutput("📁 Selected: " + selectedFile.getName() + "\n");
        }
    }
    
    private void generateRandomKey() {
        String randomKey = fileEncryption.generateRandomKey();
        encryptionKeyField.setText(randomKey);
        appendOutput("🔑 Random encryption key generated\n");
        
        // Show key in dialog for user to save
        JTextArea keyArea = new JTextArea(3, 30);
        keyArea.setText(randomKey);
        keyArea.setEditable(false);
        keyArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        
        JScrollPane scrollPane = new JScrollPane(keyArea);
        JOptionPane.showMessageDialog(this, scrollPane, 
            "Generated Encryption Key - SAVE THIS KEY!", 
            JOptionPane.INFORMATION_MESSAGE);
    }
    
    private void encryptFile() {
        String filePath = filePathField.getText().trim();
        String key = new String(encryptionKeyField.getPassword());
        String algorithm = (String) algorithmComboBox.getSelectedItem();
        
        if (filePath.isEmpty() || key.isEmpty()) {
            showError("Please select a file and enter encryption key");
            return;
        }
        
        SwingWorker<Boolean, String> worker = new SwingWorker<Boolean, String>() {
            @Override
            protected Boolean doInBackground() throws Exception {
                publish("🔄 Encrypting file: " + new File(filePath).getName());
                publish("🔐 Using algorithm: " + algorithm);
                progressBar.setIndeterminate(true);
                
                boolean result = fileEncryption.encryptFile(filePath, key, algorithm);
                
                if (result) {
                    publish("✅ File encrypted successfully!");
                    publish("🔒 Original file has been securely overwritten");
                    publish("💾 Encrypted file saved with .enc extension");
                } else {
                    publish("❌ Failed to encrypt file");
                }
                
                return result;
            }
            
            @Override
            protected void process(List<String> chunks) {
                for (String message : chunks) {
                    appendOutput(message + "\n");
                }
            }
            
            @Override
            protected void done() {
                progressBar.setIndeterminate(false);
            }
        };
        
        worker.execute();
    }
    
    private void decryptFile() {
        String filePath = filePathField.getText().trim();
        String key = new String(encryptionKeyField.getPassword());
        String algorithm = (String) algorithmComboBox.getSelectedItem();
        
        if (filePath.isEmpty() || key.isEmpty()) {
            showError("Please select a file and enter decryption key");
            return;
        }
        
        SwingWorker<Boolean, String> worker = new SwingWorker<Boolean, String>() {
            @Override
            protected Boolean doInBackground() throws Exception {
                publish("🔄 Decrypting file: " + new File(filePath).getName());
                publish("🔓 Using algorithm: " + algorithm);
                progressBar.setIndeterminate(true);
                
                boolean result = fileEncryption.decryptFile(filePath, key, algorithm);
                
                if (result) {
                    publish("✅ File decrypted successfully!");
                    publish("👁️ Decrypted file is now accessible");
                } else {
                    publish("❌ Failed to decrypt file - Check your key!");
                }
                
                return result;
            }
            
            @Override
            protected void process(List<String> chunks) {
                for (String message : chunks) {
                    appendOutput(message + "\n");
                }
            }
            
            @Override
            protected void done() {
                progressBar.setIndeterminate(false);
            }
        };
        
        worker.execute();
    }
    
    private void secureDeleteFile() {
        String filePath = filePathField.getText().trim();
        if (filePath.isEmpty()) {
            showError("Please select a file to securely delete");
            return;
        }
        
        int result = JOptionPane.showConfirmDialog(this,
            "⚠️ WARNING: This will permanently delete the file!\n" +
            "This operation cannot be undone!\n\n" +
            "Are you sure you want to continue?",
            "Secure Delete Confirmation",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE);
        
        if (result == JOptionPane.YES_OPTION) {
            SwingWorker<Boolean, String> worker = new SwingWorker<Boolean, String>() {
                @Override
                protected Boolean doInBackground() throws Exception {
                    publish("🔄 Securely deleting file: " + new File(filePath).getName());
                    publish("🗑️ Overwriting file data multiple times...");
                    progressBar.setIndeterminate(true);
                    
                    boolean deleteResult = fileEncryption.secureDelete(filePath);
                    
                    if (deleteResult) {
                        publish("✅ File securely deleted!");
                        publish("🔒 File data has been permanently destroyed");
                    } else {
                        publish("❌ Failed to securely delete file");
                    }
                    
                    return deleteResult;
                }
                
                @Override
                protected void process(List<String> chunks) {
                    for (String message : chunks) {
                        appendOutput(message + "\n");
                    }
                }
                
                @Override
                protected void done() {
                    progressBar.setIndeterminate(false);
                    filePathField.setText(""); // Clear the path since file is deleted
                }
            };
            
            worker.execute();
        }
    }
    
    private void appendOutput(String text) {
        SwingUtilities.invokeLater(() -> {
            outputArea.append(getCurrentTimestamp() + " " + text);
            outputArea.setCaretPosition(outputArea.getDocument().getLength());
        });
    }
    
    private String getCurrentTimestamp() {
        return "[" + java.time.LocalTime.now().format(
            java.time.format.DateTimeFormatter.ofPattern("HH:mm:ss")) + "]";
    }
    
    private void showError(String message) {
        JOptionPane.showMessageDialog(this, message, "Error", JOptionPane.ERROR_MESSAGE);
        appendOutput("❌ Error: " + message + "\n");
    }
}
