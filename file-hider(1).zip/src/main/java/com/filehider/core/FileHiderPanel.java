package com.filehider.core;

import com.filehider.operations.FileHider;
import com.filehider.utils.Logger;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.List;

public class FileHiderPanel extends JPanel {
    private static final Logger logger = Logger.getInstance();
    
    private JTextField filePathField;
    private JTextArea outputArea;
    private JProgressBar progressBar;
    private JList<String> hiddenFilesList;
    private DefaultListModel<String> hiddenFilesModel;
    
    private FileHider fileHider;
    
    public FileHiderPanel() {
        fileHider = new FileHider();
        initializeComponents();
        layoutComponents();
        loadHiddenFiles();
    }
    
    private void initializeComponents() {
        setBackground(new Color(45, 45, 45));
        
        filePathField = new JTextField(40);
        filePathField.setFont(new Font("Arial", Font.PLAIN, 14));
        
        outputArea = new JTextArea(12, 50);
        outputArea.setEditable(false);
        outputArea.setFont(new Font("Consolas", Font.PLAIN, 12));
        outputArea.setBackground(new Color(33, 37, 41));
        outputArea.setForeground(Color.WHITE);
        outputArea.setText("🔒 Secure File Hider Ready\n" +
                          "Select a file to hide or unhide...\n\n");
        
        progressBar = new JProgressBar();
        progressBar.setStringPainted(true);
        progressBar.setBackground(new Color(33, 37, 41));
        progressBar.setForeground(new Color(40, 167, 69));
        
        hiddenFilesModel = new DefaultListModel<>();
        hiddenFilesList = new JList<>(hiddenFilesModel);
        hiddenFilesList.setBackground(new Color(33, 37, 41));
        hiddenFilesList.setForeground(Color.WHITE);
        hiddenFilesList.setSelectionBackground(new Color(0, 123, 255));
    }
    
    private void layoutComponents() {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // Top panel - File selection
        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        topPanel.setBackground(new Color(45, 45, 45));
        topPanel.setBorder(createTitledBorder("📁 File Selection"));
        
        JLabel fileLabel = new JLabel("File Path:");
        fileLabel.setForeground(Color.WHITE);
        
        JButton browseButton = createStyledButton("Browse", new Color(0, 123, 255));
        browseButton.addActionListener(e -> browseFile());
        
        topPanel.add(fileLabel);
        topPanel.add(filePathField);
        topPanel.add(browseButton);
        
        // Center panel - Operations and output
        JPanel centerPanel = new JPanel(new BorderLayout(10, 10));
        centerPanel.setBackground(new Color(45, 45, 45));
        
        // Operations panel
        JPanel operationsPanel = new JPanel(new FlowLayout());
        operationsPanel.setBackground(new Color(45, 45, 45));
        operationsPanel.setBorder(createTitledBorder("🔧 Operations"));
        
        JButton hideButton = createStyledButton("🙈 Hide File", new Color(220, 53, 69));
        hideButton.addActionListener(e -> hideFile());
        
        JButton unhideButton = createStyledButton("👁️ Unhide File", new Color(40, 167, 69));
        unhideButton.addActionListener(e -> unhideFile());
        
        JButton refreshButton = createStyledButton("🔄 Refresh List", new Color(108, 117, 125));
        refreshButton.addActionListener(e -> loadHiddenFiles());
        
        JButton clearLogButton = createStyledButton("🗑️ Clear Log", new Color(255, 193, 7));
        clearLogButton.addActionListener(e -> outputArea.setText("Log cleared.\n"));
        
        operationsPanel.add(hideButton);
        operationsPanel.add(unhideButton);
        operationsPanel.add(refreshButton);
        operationsPanel.add(clearLogButton);
        
        // Output panel
        JScrollPane outputScrollPane = new JScrollPane(outputArea);
        outputScrollPane.setBorder(createTitledBorder("📋 Operation Log"));
        
        centerPanel.add(operationsPanel, BorderLayout.NORTH);
        centerPanel.add(outputScrollPane, BorderLayout.CENTER);
        centerPanel.add(progressBar, BorderLayout.SOUTH);
        
        // Right panel - Hidden files list
        JScrollPane hiddenFilesScrollPane = new JScrollPane(hiddenFilesList);
        hiddenFilesScrollPane.setBorder(createTitledBorder("🗂️ Hidden Files"));
        hiddenFilesScrollPane.setPreferredSize(new Dimension(250, 0));
        
        add(topPanel, BorderLayout.NORTH);
        add(centerPanel, BorderLayout.CENTER);
        add(hiddenFilesScrollPane, BorderLayout.EAST);
    }
    
    private TitledBorder createTitledBorder(String title) {
        TitledBorder border = BorderFactory.createTitledBorder(title);
        border.setTitleColor(Color.WHITE);
        return border;
    }
    
    private JButton createStyledButton(String text, Color backgroundColor) {
        JButton button = new JButton(text);
        button.setBackground(backgroundColor);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setPreferredSize(new Dimension(120, 35));
        button.setFont(new Font("Arial", Font.BOLD, 12));
        return button;
    }
    
    private void browseFile() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
        
        int result = fileChooser.showOpenDialog(this);
        if (result == JFileChooser.APPROVE_OPTION) {
            File selectedFile = fileChooser.getSelectedFile();
            filePathField.setText(selectedFile.getAbsolutePath());
            appendOutput("📁 Selected: " + selectedFile.getName() + "\n");
        }
    }
    
    private void hideFile() {
        String filePath = filePathField.getText().trim();
        if (filePath.isEmpty()) {
            showError("Please select a file to hide");
            return;
        }
        
        SwingWorker<Boolean, String> worker = new SwingWorker<Boolean, String>() {
            @Override
            protected Boolean doInBackground() throws Exception {
                publish("🔄 Hiding file: " + new File(filePath).getName());
                progressBar.setIndeterminate(true);
                
                boolean result = fileHider.hideFile(filePath);
                
                if (result) {
                    publish("✅ File hidden successfully!");
                    publish("🔒 File is now invisible to normal file explorers");
                } else {
                    publish("❌ Failed to hide file");
                }
                
                return result;
            }
            
            @Override
            protected void process(List<String> chunks) {
                for (String message : chunks) {
                    appendOutput(message + "\n");
                }
            }
            
            @Override
            protected void done() {
                progressBar.setIndeterminate(false);
                loadHiddenFiles();
            }
        };
        
        worker.execute();
    }
    
    private void unhideFile() {
        String filePath = filePathField.getText().trim();
        if (filePath.isEmpty()) {
            showError("Please select a file to unhide");
            return;
        }
        
        SwingWorker<Boolean, String> worker = new SwingWorker<Boolean, String>() {
            @Override
            protected Boolean doInBackground() throws Exception {
                publish("🔄 Unhiding file: " + new File(filePath).getName());
                progressBar.setIndeterminate(true);
                
                boolean result = fileHider.unhideFile(filePath);
                
                if (result) {
                    publish("✅ File unhidden successfully!");
                    publish("👁️ File is now visible in file explorers");
                } else {
                    publish("❌ Failed to unhide file");
                }
                
                return result;
            }
            
            @Override
            protected void process(List<String> chunks) {
                for (String message : chunks) {
                    appendOutput(message + "\n");
                }
            }
            
            @Override
            protected void done() {
                progressBar.setIndeterminate(false);
                loadHiddenFiles();
            }
        };
        
        worker.execute();
    }
    
    private void loadHiddenFiles() {
        SwingWorker<List<String>, Void> worker = new SwingWorker<List<String>, Void>() {
            @Override
            protected List<String> doInBackground() throws Exception {
                return fileHider.getHiddenFiles();
            }
            
            @Override
            protected void done() {
                try {
                    List<String> hiddenFiles = get();
                    hiddenFilesModel.clear();
                    
                    if (hiddenFiles.isEmpty()) {
                        hiddenFilesModel.addElement("No hidden files found");
                    } else {
                        for (String file : hiddenFiles) {
                            hiddenFilesModel.addElement("🔒 " + new File(file).getName());
                        }
                    }
                } catch (Exception e) {
                    logger.error("Error loading hidden files: " + e.getMessage());
                }
            }
        };
        
        worker.execute();
    }
    
    private void appendOutput(String text) {
        SwingUtilities.invokeLater(() -> {
            outputArea.append(getCurrentTimestamp() + " " + text);
            outputArea.setCaretPosition(outputArea.getDocument().getLength());
        });
    }
    
    private String getCurrentTimestamp() {
        return "[" + java.time.LocalTime.now().format(
            java.time.format.DateTimeFormatter.ofPattern("HH:mm:ss")) + "]";
    }
    
    private void showError(String message) {
        JOptionPane.showMessageDialog(this, message, "Error", JOptionPane.ERROR_MESSAGE);
        appendOutput("❌ Error: " + message + "\n");
    }
}
