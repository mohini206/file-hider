import javax.swing.*;
import javax.swing.border.TitledBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.nio.file.*;
import java.nio.file.attribute.DosFileAttributes;
import java.util.List;

public class EnhancedFileHiderGUI extends JFrame {
    private JTextField filePathField;
    private JTextField encryptionKeyField;
    private JComboBox<String> algorithmComboBox;
    private JTextArea outputArea;
    private JProgressBar progressBar;
    
    private JButton hideButton, unhideButton, browseButton, checkStatusButton;
    private JButton encryptButton, decryptButton, generateKeyButton, secureDeleteButton;
    private JButton scanButton, clearLogButton;
    
    private SimpleFileHider fileHider;
    private FileEncryption fileEncryption;
    
    public EnhancedFileHiderGUI() {
        fileHider = new SimpleFileHider();
        fileEncryption = new FileEncryption();
        initializeGUI();
    }
    
    private void initializeGUI() {
        setTitle("🔒 Enhanced File Hider & Encryption Tool");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
        
        createComponents();
        layoutComponents();
        addEventListeners();
        
        setSize(800, 600);
        setLocationRelativeTo(null);
        
        // Set dark theme colors
        getContentPane().setBackground(new Color(45, 45, 45));
    }
    
    private void createComponents() {
        // Text fields
        filePathField = new JTextField(40);
        filePathField.setFont(new Font("Arial", Font.PLAIN, 14));
        
        encryptionKeyField = new JTextField(20);
        encryptionKeyField.setFont(new Font("Arial", Font.PLAIN, 14));
        
        // Algorithm combo box
        algorithmComboBox = new JComboBox<>(new String[]{"AES-128", "AES-256", "DES"});
        algorithmComboBox.setSelectedIndex(1); // Default to AES-256
        
        // Output area
        outputArea = new JTextArea(15, 60);
        outputArea.setEditable(false);
        outputArea.setFont(new Font("Consolas", Font.PLAIN, 12));
        outputArea.setBackground(new Color(33, 37, 41));
        outputArea.setForeground(Color.WHITE);
        outputArea.setText("🔒 Enhanced File Hider Ready\n" +
                          "Select a file to hide, unhide, or encrypt...\n\n");
        
        // Progress bar
        progressBar = new JProgressBar();
        progressBar.setStringPainted(true);
        progressBar.setString("Ready");
        
        // Buttons
        browseButton = createStyledButton("📁 Browse", new Color(0, 123, 255));
        hideButton = createStyledButton("🙈 Hide File", new Color(220, 53, 69));
        unhideButton = createStyledButton("👁️ Unhide File", new Color(40, 167, 69));
        checkStatusButton = createStyledButton("🔍 Check Status", new Color(108, 117, 125));
        
        encryptButton = createStyledButton("🔒 Encrypt", new Color(220, 53, 69));
        decryptButton = createStyledButton("🔓 Decrypt", new Color(40, 167, 69));
        generateKeyButton = createStyledButton("🔑 Generate Key", new Color(255, 193, 7));
        secureDeleteButton = createStyledButton("🗑️ Secure Delete", new Color(108, 117, 125));
        
        scanButton = createStyledButton("🔍 Scan Directory", new Color(0, 123, 255));
        clearLogButton = createStyledButton("📋 Clear Log", new Color(255, 193, 7));
    }
    
    private JButton createStyledButton(String text, Color backgroundColor) {
        JButton button = new JButton(text);
        button.setBackground(backgroundColor);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setPreferredSize(new Dimension(140, 35));
        button.setFont(new Font("Arial", Font.BOLD, 12));
        return button;
    }
    
    private void layoutComponents() {
        // Main panel
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBackground(new Color(45, 45, 45));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // Top panel - File selection
        JPanel topPanel = new JPanel(new GridBagLayout());
        topPanel.setBackground(new Color(45, 45, 45));
        topPanel.setBorder(createTitledBorder("📁 File Selection"));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        
        gbc.gridx = 0; gbc.gridy = 0; gbc.anchor = GridBagConstraints.WEST;
        JLabel fileLabel = new JLabel("File Path:");
        fileLabel.setForeground(Color.WHITE);
        topPanel.add(fileLabel, gbc);
        
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        topPanel.add(filePathField, gbc);
        
        gbc.gridx = 2; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        topPanel.add(browseButton, gbc);
        
        // Encryption settings
        gbc.gridx = 0; gbc.gridy = 1; gbc.anchor = GridBagConstraints.WEST;
        JLabel keyLabel = new JLabel("Encryption Key:");
        keyLabel.setForeground(Color.WHITE);
        topPanel.add(keyLabel, gbc);
        
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        topPanel.add(encryptionKeyField, gbc);
        
        gbc.gridx = 2; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        topPanel.add(generateKeyButton, gbc);
        
        gbc.gridx = 0; gbc.gridy = 2; gbc.anchor = GridBagConstraints.WEST;
        JLabel algorithmLabel = new JLabel("Algorithm:");
        algorithmLabel.setForeground(Color.WHITE);
        topPanel.add(algorithmLabel, gbc);
        
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL;
        topPanel.add(algorithmComboBox, gbc);
        
        // Center panel - Operations
        JPanel centerPanel = new JPanel(new BorderLayout(10, 10));
        centerPanel.setBackground(new Color(45, 45, 45));
        
        // File operations panel
        JPanel fileOpsPanel = new JPanel(new FlowLayout());
        fileOpsPanel.setBackground(new Color(45, 45, 45));
        fileOpsPanel.setBorder(createTitledBorder("🗂️ File Operations"));
        
        fileOpsPanel.add(hideButton);
        fileOpsPanel.add(unhideButton);
        fileOpsPanel.add(checkStatusButton);
        fileOpsPanel.add(scanButton);
        
        // Encryption operations panel
        JPanel encryptOpsPanel = new JPanel(new FlowLayout());
        encryptOpsPanel.setBackground(new Color(45, 45, 45));
        encryptOpsPanel.setBorder(createTitledBorder("🔐 Encryption Operations"));
        
        encryptOpsPanel.add(encryptButton);
        encryptOpsPanel.add(decryptButton);
        encryptOpsPanel.add(secureDeleteButton);
        encryptOpsPanel.add(clearLogButton);
        
        // Operations container
        JPanel operationsContainer = new JPanel(new GridLayout(2, 1, 5, 5));
        operationsContainer.setBackground(new Color(45, 45, 45));
        operationsContainer.add(fileOpsPanel);
        operationsContainer.add(encryptOpsPanel);
        
        // Output panel
        JScrollPane outputScrollPane = new JScrollPane(outputArea);
        outputScrollPane.setBorder(createTitledBorder("📋 Operation Log"));
        
        centerPanel.add(operationsContainer, BorderLayout.NORTH);
        centerPanel.add(outputScrollPane, BorderLayout.CENTER);
        centerPanel.add(progressBar, BorderLayout.SOUTH);
        
        mainPanel.add(topPanel, BorderLayout.NORTH);
        mainPanel.add(centerPanel, BorderLayout.CENTER);
        
        add(mainPanel);
    }
    
    private TitledBorder createTitledBorder(String title) {
        TitledBorder border = BorderFactory.createTitledBorder(title);
        border.setTitleColor(Color.WHITE);
        return border;
    }
    
    private void addEventListeners() {
        browseButton.addActionListener(e -> browseForFile());
        hideButton.addActionListener(e -> performOperation("hide"));
        unhideButton.addActionListener(e -> performOperation("unhide"));
        checkStatusButton.addActionListener(e -> performOperation("check"));
        scanButton.addActionListener(e -> performOperation("scan"));
        
        encryptButton.addActionListener(e -> performOperation("encrypt"));
        decryptButton.addActionListener(e -> performOperation("decrypt"));
        generateKeyButton.addActionListener(e -> generateRandomKey());
        secureDeleteButton.addActionListener(e -> performOperation("secureDelete"));
        clearLogButton.addActionListener(e -> clearLog());
    }
    
    private void browseForFile() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
        
        int result = fileChooser.showOpenDialog(this);
        if (result == JFileChooser.APPROVE_OPTION) {
            File selectedFile = fileChooser.getSelectedFile();
            filePathField.setText(selectedFile.getAbsolutePath());
            appendOutput("📁 Selected: " + selectedFile.getName() + "\n");
        }
    }
    
    private void performOperation(String operation) {
        String filePath = filePathField.getText().trim();
        
        if (filePath.isEmpty() && !operation.equals("scan")) {
            appendOutput("❌ Please select a file first.\n");
            return;
        }
        
        // Use SwingWorker for background operations
        SwingWorker<Boolean, String> worker = new SwingWorker<Boolean, String>() {
            @Override
            protected Boolean doInBackground() throws Exception {
                progressBar.setIndeterminate(true);
                progressBar.setString("Processing...");
                
                switch (operation) {
                    case "hide":
                        publish("🔄 Hiding file: " + new File(filePath).getName());
                        return fileHider.hideFile(filePath);
                        
                    case "unhide":
                        publish("🔄 Unhiding file: " + new File(filePath).getName());
                        return fileHider.unhideFile(filePath);
                        
                    case "check":
                        publish("🔍 Checking file status...");
                        boolean hidden = fileHider.isFileHidden(filePath);
                        publish("File: " + filePath);
                        publish("Status: " + (hidden ? "Hidden ✅" : "Visible 👁️"));
                        return true;
                        
                    case "scan":
                        String scanPath = filePath.isEmpty() ? System.getProperty("user.home") : filePath;
                        publish("🔍 Scanning directory: " + scanPath);
                        List<String> hiddenFiles = fileHider.findHiddenFiles(scanPath);
                        publish("Found " + hiddenFiles.size() + " hidden files:");
                        hiddenFiles.forEach(file -> publish("  🔒 " + file));
                        return true;
                        
                    case "encrypt":
                        String key = encryptionKeyField.getText().trim();
                        if (key.isEmpty()) {
                            publish("❌ Please enter an encryption key");
                            return false;
                        }
                        String algorithm = (String) algorithmComboBox.getSelectedItem();
                        publish("🔐 Encrypting file with " + algorithm + "...");
                        return fileEncryption.encryptFile(filePath, key, algorithm);
                        
                    case "decrypt":
                        String decryptKey = encryptionKeyField.getText().trim();
                        if (decryptKey.isEmpty()) {
                            publish("❌ Please enter the decryption key");
                            return false;
                        }
                        String decryptAlgorithm = (String) algorithmComboBox.getSelectedItem();
                        publish("🔓 Decrypting file with " + decryptAlgorithm + "...");
                        return fileEncryption.decryptFile(filePath, decryptKey, decryptAlgorithm);
                        
                    case "secureDelete":
                        int result = JOptionPane.showConfirmDialog(
                            EnhancedFileHiderGUI.this,
                            "⚠️ WARNING: This will permanently delete the file!\n" +
                            "This operation cannot be undone!\n\n" +
                            "Are you sure you want to continue?",
                            "Secure Delete Confirmation",
                            JOptionPane.YES_NO_OPTION,
                            JOptionPane.WARNING_MESSAGE);
                        
                        if (result == JOptionPane.YES_OPTION) {
                            publish("🗑️ Securely deleting file...");
                            return fileEncryption.secureDelete(filePath);
                        }
                        return false;
                }
                
                return false;
            }
            
            @Override
            protected void process(List<String> chunks) {
                for (String message : chunks) {
                    appendOutput(message + "\n");
                }
            }
            
            @Override
            protected void done() {
                progressBar.setIndeterminate(false);
                progressBar.setString("Ready");
                
                try {
                    Boolean result = get();
                    if (result != null) {
                        String status = result ? "✅ Operation completed successfully!" : "❌ Operation failed!";
                        appendOutput(status + "\n\n");
                    }
                } catch (Exception e) {
                    appendOutput("❌ Error: " + e.getMessage() + "\n\n");
                }
            }
        };
        
        worker.execute();
    }
    
    private void generateRandomKey() {
        String algorithm = (String) algorithmComboBox.getSelectedItem();
        String randomKey = fileEncryption.generateRandomKey(algorithm);
        encryptionKeyField.setText(randomKey);
        appendOutput("🔑 Random " + algorithm + " key generated\n");
        
        // Show key in dialog for user to save
        JTextArea keyArea = new JTextArea(3, 40);
        keyArea.setText(randomKey);
        keyArea.setEditable(false);
        keyArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        keyArea.setBackground(Color.BLACK);
        keyArea.setForeground(Color.GREEN);
        
        JScrollPane scrollPane = new JScrollPane(keyArea);
        JOptionPane.showMessageDialog(this, scrollPane, 
            "🔑 Generated Encryption Key - SAVE THIS KEY!", 
            JOptionPane.INFORMATION_MESSAGE);
    }
    
    private void clearLog() {
        outputArea.setText("📋 Log cleared.\n");
    }
    
    private void appendOutput(String text) {
        SwingUtilities.invokeLater(() -> {
            outputArea.append(getCurrentTimestamp() + " " + text);
            outputArea.setCaretPosition(outputArea.getDocument().getLength());
        });
    }
    
    private String getCurrentTimestamp() {
        return "[" + java.time.LocalTime.now().format(
            java.time.format.DateTimeFormatter.ofPattern("HH:mm:ss")) + "]";
    }
    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeel());
            } catch (Exception e) {
                e.printStackTrace();
            }
            
            new EnhancedFileHiderGUI().setVisible(true);
        });
    }
}
