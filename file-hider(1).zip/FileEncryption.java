import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.SecureRandom;
import java.util.Base64;

public class FileEncryption {
    
    public boolean encryptFile(String filePath, String key, String algorithm) {
        try {
            File inputFile = new File(filePath);
            if (!inputFile.exists()) {
                System.err.println("File does not exist: " + filePath);
                return false;
            }
            
            // Read file content
            byte[] fileContent = Files.readAllBytes(Paths.get(filePath));
            
            // Encrypt content
            byte[] encryptedContent = encrypt(fileContent, key, algorithm);
            
            if (encryptedContent != null) {
                // Write encrypted content to new file
                String encryptedFilePath = filePath + ".enc";
                Files.write(Paths.get(encryptedFilePath), encryptedContent);
                
                // Optionally delete original file
                System.out.println("File encrypted successfully: " + filePath);
                System.out.println("Encrypted file saved as: " + encryptedFilePath);
                return true;
            }
            
        } catch (Exception e) {
            System.err.println("Error encrypting file: " + e.getMessage());
        }
        
        return false;
    }
    
    public boolean decryptFile(String filePath, String key, String algorithm) {
        try {
            File inputFile = new File(filePath);
            if (!inputFile.exists()) {
                System.err.println("File does not exist: " + filePath);
                return false;
            }
            
            // Read encrypted content
            byte[] encryptedContent = Files.readAllBytes(Paths.get(filePath));
            
            // Decrypt content
            byte[] decryptedContent = decrypt(encryptedContent, key, algorithm);
            
            if (decryptedContent != null) {
                // Write decrypted content to new file
                String decryptedFilePath = filePath.replace(".enc", "_decrypted");
                if (decryptedFilePath.equals(filePath)) {
                    decryptedFilePath = filePath + "_decrypted";
                }
                Files.write(Paths.get(decryptedFilePath), decryptedContent);
                
                System.out.println("File decrypted successfully: " + filePath);
                System.out.println("Decrypted file saved as: " + decryptedFilePath);
                return true;
            }
            
        } catch (Exception e) {
            System.err.println("Error decrypting file: " + e.getMessage());
        }
        
        return false;
    }
    
    private byte[] encrypt(byte[] data, String key, String algorithm) {
        try {
            String transformation = getTransformation(algorithm);
            Cipher cipher = Cipher.getInstance(transformation);
            
            // Ensure key is the right length
            byte[] keyBytes = adjustKeyLength(key.getBytes(), getKeyLength(algorithm));
            SecretKeySpec secretKey = new SecretKeySpec(keyBytes, getAlgorithmName(algorithm));
            
            cipher.init(Cipher.ENCRYPT_MODE, secretKey);
            return cipher.doFinal(data);
            
        } catch (Exception e) {
            System.err.println("Error during encryption: " + e.getMessage());
            return null;
        }
    }
    
    private byte[] decrypt(byte[] encryptedData, String key, String algorithm) {
        try {
            String transformation = getTransformation(algorithm);
            Cipher cipher = Cipher.getInstance(transformation);
            
            // Ensure key is the right length
            byte[] keyBytes = adjustKeyLength(key.getBytes(), getKeyLength(algorithm));
            SecretKeySpec secretKey = new SecretKeySpec(keyBytes, getAlgorithmName(algorithm));
            
            cipher.init(Cipher.DECRYPT_MODE, secretKey);
            return cipher.doFinal(encryptedData);
            
        } catch (Exception e) {
            System.err.println("Error during decryption: " + e.getMessage());
            return null;
        }
    }
    
    private String getTransformation(String algorithm) {
        switch (algorithm.toUpperCase()) {
            case "AES-256":
            case "AES-128":
            case "AES":
                return "AES";
            case "DES":
                return "DES";
            default:
                return "AES";
        }
    }
    
    private String getAlgorithmName(String algorithm) {
        switch (algorithm.toUpperCase()) {
            case "AES-256":
            case "AES-128":
            case "AES":
                return "AES";
            case "DES":
                return "DES";
            default:
                return "AES";
        }
    }
    
    private int getKeyLength(String algorithm) {
        switch (algorithm.toUpperCase()) {
            case "AES-256":
                return 32; // 256 bits
            case "AES-128":
            case "AES":
                return 16; // 128 bits
            case "DES":
                return 8;  // 64 bits
            default:
                return 16;
        }
    }
    
    private byte[] adjustKeyLength(byte[] key, int requiredLength) {
        byte[] adjustedKey = new byte[requiredLength];
        
        if (key.length >= requiredLength) {
            // Truncate if too long
            System.arraycopy(key, 0, adjustedKey, 0, requiredLength);
        } else {
            // Pad if too short
            System.arraycopy(key, 0, adjustedKey, 0, key.length);
            // Fill remaining with zeros (or you could repeat the key)
            for (int i = key.length; i < requiredLength; i++) {
                adjustedKey[i] = 0;
            }
        }
        
        return adjustedKey;
    }
    
    public String generateRandomKey(String algorithm) {
        try {
            String algorithmName = getAlgorithmName(algorithm);
            KeyGenerator keyGenerator = KeyGenerator.getInstance(algorithmName);
            
            if (algorithmName.equals("AES")) {
                keyGenerator.init(algorithm.contains("256") ? 256 : 128);
            } else if (algorithmName.equals("DES")) {
                keyGenerator.init(56); // DES uses 56-bit keys
            }
            
            SecretKey secretKey = keyGenerator.generateKey();
            return Base64.getEncoder().encodeToString(secretKey.getEncoded());
            
        } catch (Exception e) {
            System.err.println("Error generating random key: " + e.getMessage());
            
            // Fallback: generate random string
            SecureRandom random = new SecureRandom();
            int keyLength = getKeyLength(algorithm);
            byte[] keyBytes = new byte[keyLength];
            random.nextBytes(keyBytes);
            return Base64.getEncoder().encodeToString(keyBytes);
        }
    }
    
    public boolean secureDelete(String filePath) {
        try {
            File file = new File(filePath);
            if (!file.exists()) {
                return false;
            }
            
            long fileSize = file.length();
            
            // Overwrite file content multiple times
            try (RandomAccessFile raf = new RandomAccessFile(file, "rws")) {
                SecureRandom random = new SecureRandom();
                
                // Perform 3 overwrite passes
                for (int pass = 0; pass < 3; pass++) {
                    raf.seek(0);
                    
                    byte[] buffer = new byte[8192];
                    long remaining = fileSize;
                    
                    while (remaining > 0) {
                        int bytesToWrite = (int) Math.min(buffer.length, remaining);
                        random.nextBytes(buffer);
                        raf.write(buffer, 0, bytesToWrite);
                        remaining -= bytesToWrite;
                    }
                    
                    raf.getFD().sync(); // Force write to disk
                }
            }
            
            // Delete the file
            boolean deleted = file.delete();
            if (deleted) {
                System.out.println("File securely deleted: " + filePath);
            }
            
            return deleted;
            
        } catch (Exception e) {
            System.err.println("Error securely deleting file: " + e.getMessage());
            return false;
        }
    }
    
    // Test method
    public static void main(String[] args) {
        FileEncryption encryption = new FileEncryption();
        
        if (args.length < 3) {
            System.out.println("Usage: java FileEncryption <encrypt|decrypt|genkey> <file_path> <key> [algorithm]");
            System.out.println("Algorithms: AES-128, AES-256, DES");
            System.out.println("Examples:");
            System.out.println("  java FileEncryption encrypt test.txt mypassword AES-256");
            System.out.println("  java FileEncryption decrypt test.txt.enc mypassword AES-256");
            System.out.println("  java FileEncryption genkey - - AES-256");
            return;
        }
        
        String operation = args[0].toLowerCase();
        String filePath = args[1];
        String key = args[2];
        String algorithm = args.length > 3 ? args[3] : "AES-128";
        
        switch (operation) {
            case "encrypt":
                boolean encrypted = encryption.encryptFile(filePath, key, algorithm);
                System.out.println("Encryption " + (encrypted ? "successful" : "failed"));
                break;
                
            case "decrypt":
                boolean decrypted = encryption.decryptFile(filePath, key, algorithm);
                System.out.println("Decryption " + (decrypted ? "successful" : "failed"));
                break;
                
            case "genkey":
                String randomKey = encryption.generateRandomKey(algorithm);
                System.out.println("Generated key for " + algorithm + ": " + randomKey);
                break;
                
            default:
                System.out.println("Unknown operation: " + operation);
                break;
        }
    }
}
