import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.nio.file.*;
import java.nio.file.attribute.DosFileAttributes;

public class FileHiderGUI extends JFrame {
    private JTextField filePathField;
    private JTextArea outputArea;
    private JButton hideButton, unhideButton, browseButton, checkStatusButton;
    
    public FileHiderGUI() {
        initializeGUI();
    }
    
    private void initializeGUI() {
        setTitle("🔒 File Hider Application");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
        
        // Create components
        createComponents();
        layoutComponents();
        addEventListeners();
        
        setSize(700, 500);
        setLocationRelativeTo(null);
        
        // Set colors for better appearance
        getContentPane().setBackground(new Color(240, 240, 240));
    }
    
    private void createComponents() {
        filePathField = new JTextField(40);
        filePathField.setFont(new Font("Arial", Font.PLAIN, 14));
        
        outputArea = new JTextArea(15, 50);
        outputArea.setEditable(false);
        outputArea.setFont(new Font("Consolas", Font.PLAIN, 12));
        outputArea.setBackground(new Color(248, 248, 248));
        outputArea.setText("🔒 File Hider Ready\nSelect a file to hide or unhide...\n\n");
        
        hideButton = new JButton("🙈 Hide File");
        hideButton.setBackground(new Color(220, 53, 69));
        hideButton.setForeground(Color.WHITE);
        hideButton.setPreferredSize(new Dimension(120, 35));
        
        unhideButton = new JButton("👁️ Unhide File");
        unhideButton.setBackground(new Color(40, 167, 69));
        unhideButton.setForeground(Color.WHITE);
        unhideButton.setPreferredSize(new Dimension(120, 35));
        
        browseButton = new JButton("📁 Browse");
        browseButton.setBackground(new Color(0, 123, 255));
        browseButton.setForeground(Color.WHITE);
        browseButton.setPreferredSize(new Dimension(100, 35));
        
        checkStatusButton = new JButton("🔍 Check Status");
        checkStatusButton.setBackground(new Color(108, 117, 125));
        checkStatusButton.setForeground(Color.WHITE);
        checkStatusButton.setPreferredSize(new Dimension(130, 35));
    }
    
    private void layoutComponents() {
        // Top panel for file selection
        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        topPanel.setBackground(new Color(240, 240, 240));
        topPanel.setBorder(BorderFactory.createTitledBorder("📁 File Selection"));
        
        JLabel fileLabel = new JLabel("File Path:");
        fileLabel.setFont(new Font("Arial", Font.BOLD, 12));
        
        topPanel.add(fileLabel);
        topPanel.add(filePathField);
        topPanel.add(browseButton);
        
        // Middle panel for buttons
        JPanel buttonPanel = new JPanel(new FlowLayout());
        buttonPanel.setBackground(new Color(240, 240, 240));
        buttonPanel.setBorder(BorderFactory.createTitledBorder("🔧 Operations"));
        
        buttonPanel.add(hideButton);
        buttonPanel.add(unhideButton);
        buttonPanel.add(checkStatusButton);
        
        // Bottom panel for output
        JScrollPane scrollPane = new JScrollPane(outputArea);
        scrollPane.setBorder(BorderFactory.createTitledBorder("📋 Output Log"));
        scrollPane.setPreferredSize(new Dimension(680, 250));
        
        add(topPanel, BorderLayout.NORTH);
        add(buttonPanel, BorderLayout.CENTER);
        add(scrollPane, BorderLayout.SOUTH);
    }
    
    private void addEventListeners() {
        browseButton.addActionListener(e -> browseForFile());
        hideButton.addActionListener(e -> hideFile());
        unhideButton.addActionListener(e -> unhideFile());
        checkStatusButton.addActionListener(e -> checkFileStatus());
    }
    
    private void browseForFile() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
        
        int result = fileChooser.showOpenDialog(this);
        if (result == JFileChooser.APPROVE_OPTION) {
            File selectedFile = fileChooser.getSelectedFile();
            filePathField.setText(selectedFile.getAbsolutePath());
            appendOutput("📁 Selected: " + selectedFile.getName() + "\n");
        }
    }
    
    private void hideFile() {
        String filePath = filePathField.getText().trim();
        if (filePath.isEmpty()) {
            appendOutput("❌ Please select a file first.\n");
            return;
        }
        
        try {
            Path path = Paths.get(filePath);
            
            if (!Files.exists(path)) {
                appendOutput("❌ File does not exist: " + filePath + "\n");
                return;
            }
            
            appendOutput("🔄 Hiding file: " + path.getFileName() + "\n");
            
            if (isWindows()) {
                // Windows: Set hidden attribute
                Files.setAttribute(path, "dos:hidden", true);
                appendOutput("✅ File hidden using Windows hidden attribute\n");
            } else {
                // Unix/Linux: Rename with dot prefix
                Path parent = path.getParent();
                String fileName = path.getFileName().toString();
                
                if (!fileName.startsWith(".")) {
                    Path hiddenPath = parent.resolve("." + fileName);
                    Files.move(path, hiddenPath);
                    filePathField.setText(hiddenPath.toString());
                    appendOutput("✅ File renamed to: " + hiddenPath.getFileName() + "\n");
                } else {
                    appendOutput("⚠️ File is already hidden (starts with dot)\n");
                    return;
                }
            }
            
            appendOutput("🔒 File hidden successfully!\n");
            appendOutput("📍 Location: " + filePath + "\n\n");
            
        } catch (IOException e) {
            appendOutput("❌ Error hiding file: " + e.getMessage() + "\n\n");
        }
    }
    
    private void unhideFile() {
        String filePath = filePathField.getText().trim();
        if (filePath.isEmpty()) {
            appendOutput("❌ Please select a file first.\n");
            return;
        }
        
        try {
            Path path = Paths.get(filePath);
            
            if (!Files.exists(path)) {
                appendOutput("❌ File does not exist: " + filePath + "\n");
                return;
            }
            
            appendOutput("🔄 Unhiding file: " + path.getFileName() + "\n");
            
            if (isWindows()) {
                // Windows: Remove hidden attribute
                Files.setAttribute(path, "dos:hidden", false);
                appendOutput("✅ File unhidden using Windows attribute removal\n");
            } else {
                // Unix/Linux: Remove dot prefix
                Path parent = path.getParent();
                String fileName = path.getFileName().toString();
                
                if (fileName.startsWith(".")) {
                    String unhiddenName = fileName.substring(1);
                    Path unhiddenPath = parent.resolve(unhiddenName);
                    Files.move(path, unhiddenPath);
                    filePathField.setText(unhiddenPath.toString());
                    appendOutput("✅ File renamed to: " + unhiddenPath.getFileName() + "\n");
                } else {
                    appendOutput("⚠️ File is not hidden (doesn't start with dot)\n");
                    return;
                }
            }
            
            appendOutput("👁️ File unhidden successfully!\n");
            appendOutput("📍 Location: " + filePathField.getText() + "\n\n");
            
        } catch (IOException e) {
            appendOutput("❌ Error unhiding file: " + e.getMessage() + "\n\n");
        }
    }
    
    private void checkFileStatus() {
        String filePath = filePathField.getText().trim();
        if (filePath.isEmpty()) {
            appendOutput("❌ Please select a file first.\n");
            return;
        }
        
        try {
            Path path = Paths.get(filePath);
            
            if (!Files.exists(path)) {
                appendOutput("❌ File does not exist: " + filePath + "\n");
                return;
            }
            
            boolean hidden = isHidden(path);
            String fileSize = formatFileSize(Files.size(path));
            
            appendOutput("=== 📊 FILE STATUS REPORT ===\n");
            appendOutput("📁 File: " + path.getFileName() + "\n");
            appendOutput("📍 Path: " + filePath + "\n");
            appendOutput("👁️ Status: " + (hidden ? "🔒 HIDDEN" : "👀 VISIBLE") + "\n");
            appendOutput("📏 Size: " + fileSize + "\n");
            appendOutput("📅 Last Modified: " + Files.getLastModifiedTime(path) + "\n");
            appendOutput("💻 System: " + (isWindows() ? "Windows" : "Unix/Linux") + "\n");
            
            if (isWindows()) {
                try {
                    DosFileAttributes attrs = Files.readAttributes(path, DosFileAttributes.class);
                    appendOutput("🔧 Attributes: " + 
                        (attrs.isReadOnly() ? "ReadOnly " : "") +
                        (attrs.isHidden() ? "Hidden " : "") +
                        (attrs.isSystem() ? "System " : "") +
                        (attrs.isArchive() ? "Archive " : "") + "\n");
                } catch (IOException e) {
                    appendOutput("⚠️ Could not read file attributes\n");
                }
            }
            
            appendOutput("==============================\n\n");
            
        } catch (IOException e) {
            appendOutput("❌ Error checking file: " + e.getMessage() + "\n\n");
        }
    }
    
    private boolean isHidden(Path path) {
        try {
            if (isWindows()) {
                DosFileAttributes attrs = Files.readAttributes(path, DosFileAttributes.class);
                return attrs.isHidden();
            } else {
                return path.getFileName().toString().startsWith(".");
            }
        } catch (IOException e) {
            return false;
        }
    }
    
    private boolean isWindows() {
        return System.getProperty("os.name").toLowerCase().contains("windows");
    }
    
    private String formatFileSize(long bytes) {
        if (bytes < 1024) return bytes + " bytes";
        if (bytes < 1024 * 1024) return String.format("%.1f KB", bytes / 1024.0);
        if (bytes < 1024 * 1024 * 1024) return String.format("%.1f MB", bytes / (1024.0 * 1024));
        return String.format("%.1f GB", bytes / (1024.0 * 1024 * 1024));
    }
    
    private void appendOutput(String text) {
        SwingUtilities.invokeLater(() -> {
            outputArea.append(getCurrentTimestamp() + " " + text);
            outputArea.setCaretPosition(outputArea.getDocument().getLength());
        });
    }
    
    private String getCurrentTimestamp() {
        return "[" + java.time.LocalTime.now().format(
            java.time.format.DateTimeFormatter.ofPattern("HH:mm:ss")) + "]";
    }
    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                // Set system look and feel (fixed the import issue)
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeel());
            } catch (Exception e) {
                // If system L&F fails, use default
                System.out.println("Could not set system look and feel, using default");
            }
            
            new FileHiderGUI().setVisible(true);
        });
    }
}
